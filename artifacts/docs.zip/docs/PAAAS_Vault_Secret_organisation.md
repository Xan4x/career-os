# PAAAS Vault Secret Organisation

The PAAAS secrets will be stored in vault in engine "paaas".
We describe below the organisation of the vault.

```mermaid
graph LR

    A --- Q(app_role)
    Q --- T(paaas-service-init-r)
    Q --- U(paaas-service-init-w)
    Q --- V(paaas-service-user-ro)
    Q --- W(paaas-service-role-ro)
    
     %% Color app_role paaas-awxdata-ro
        linkStyle 0 stroke:#8f0a3c,stroke-width:2px
        linkStyle 1 stroke:#8f0a3c,stroke-width:2px
        linkStyle 2 stroke:#8f0a3c,stroke-width:2px
        linkStyle 3 stroke:#8f0a3c,stroke-width:2px
        linkStyle 4 stroke:#8f0a3c,stroke-width:2px

    S --- CA(global)
    CA --- CB(registry: registry secrets)
    CA --- CC(production: prod vars)
    CA --- CD(service global vars)

    %% Color app_role: paaas-service-init-r
        linkStyle 5 stroke:#1ecfff,stroke-width:2px
        linkStyle 6 stroke:#1ecfff,stroke-width:2px
        linkStyle 7 stroke:#1ecfff,stroke-width:2px
        linkStyle 8 stroke:#1ecfff,stroke-width:2px

    %% user access: sys-squad
    A(paaas) --- S(service)
    S --- B(bubbles)
    B --- C(bubble-name)
    C --- D(auth_key)
    D --- E(warpgate: public key)

     %% Color user access: sys-squad
        linkStyle 9 stroke:#d7a21e,stroke-width:2px
        linkStyle 10 stroke:#d7a21e,stroke-width:2px
        linkStyle 11 stroke:#d7a21e,stroke-width:2px
        linkStyle 12 stroke:#d7a21e,stroke-width:2px
        linkStyle 13 stroke:#d7a21e,stroke-width:2px

    %% app_role: paaas-service-init-w
    A(paaas) --- S(service)
    S --- B
    B --- C
    C --- D
    D --- E
    C --- K(local_users)
    K --- L(warpgate: warpgate secrets)
    K --- N(nodered: secrets & url)
    K --- AC(squad_users)
    AC --- AD(squad name)
    AD --- AE(username: password)


     %% Color app_role paaas-service-w
        linkStyle 14 stroke:#FA835C,stroke-width:2px
        linkStyle 15 stroke:#FA835C,stroke-width:2px
        linkStyle 16 stroke:#FA835C,stroke-width:2px
        linkStyle 17 stroke:#FA835C,stroke-width:2px
        linkStyle 18 stroke:#FA835C,stroke-width:2px
        linkStyle 19 stroke:#FA835C,stroke-width:2px
        linkStyle 20 stroke:#FA835C,stroke-width:2px
        linkStyle 21 stroke:#FA835C,stroke-width:2px
        linkStyle 22 stroke:#FA835C,stroke-width:2px
        linkStyle 23 stroke:#FA835C,stroke-width:2px
        linkStyle 24 stroke:#FA835C,stroke-width:2px

    %% app_role: paaas-service-init-r
    A --- S
    S --- B
    B --- C
    C --- K
    K --- L
    K --- N

     %% Color app_role paaas-service-init-r
        linkStyle 25 stroke:#1ecfff,stroke-width:2px
        linkStyle 26 stroke:#1ecfff,stroke-width:2px
        linkStyle 27 stroke:#1ecfff,stroke-width:2px
        linkStyle 28 stroke:#1ecfff,stroke-width:2px
        linkStyle 29 stroke:#1ecfff,stroke-width:2px
        linkStyle 30 stroke:#1ecfff,stroke-width:2px
        
    %% user access: sys-squad (part 2)

    S --- F(squads)
    F --- Z(ssh_key)
    Z --- G(squad name)
    G --- H(username: public key)

     %% Color user access: sys-squad (part 2)
        linkStyle 31 stroke:#d7a21e,stroke-width:2px
        linkStyle 32 stroke:#d7a21e,stroke-width:2px
        linkStyle 33 stroke:#d7a21e,stroke-width:2px
        linkStyle 34 stroke:#d7a21e,stroke-width:2px

    %% app_role: paaas-service-user-ro
    A --- S
    S --- F
    F --- Z
    Z --- G
    G --- H
    F --- I(user_list)
    I --- J(squad name: list of users)

     %% Color app_role paaas-service-user-ro
        linkStyle 35 stroke:#a870fd,stroke-width:2px
        linkStyle 36 stroke:#a870fd,stroke-width:2px
        linkStyle 37 stroke:#a870fd,stroke-width:2px
        linkStyle 38 stroke:#a870fd,stroke-width:2px
        linkStyle 39 stroke:#a870fd,stroke-width:2px
        linkStyle 40 stroke:#a870fd,stroke-width:2px
        linkStyle 41 stroke:#a870fd,stroke-width:2px

    %% app_role: paaas-service-role-ro
    A --- S
    S --- F
    F --- I
    I --- J
    F --- BA(targets_list)
    BA --- BB(squad name: list of targets)

     %% Color app_role paaas-service-role-ro
        linkStyle 42 stroke:#67C7A9,stroke-width:2px
        linkStyle 43 stroke:#67C7A9,stroke-width:2px
        linkStyle 44 stroke:#67C7A9,stroke-width:2px
        linkStyle 45 stroke:#67C7A9,stroke-width:2px
        linkStyle 46 stroke:#67C7A9,stroke-width:2px
        linkStyle 47 stroke:#67C7A9,stroke-width:2px
```

## Access

Only PAAAS squad can access to the complete tree of paaas secret.

Some users policies & app_roles have beeen (or will be) defined/created:

### app_roles

- <span class="text-blue">paaas-service-init-r</span>:

``` hcl
path "paaas/data/service/bubbles/+/local_users/*"
{
    capabilities = ["read"]
}

path "paaas/data/service/global/*"
{
    capabilities = ["read"]
}

path "paaas/metadata/*"
{
    capabilities = ["list"]
} 
```

- <span class="text-corail">paaas-service-init-w</span>:

``` hcl
path "paaas/data/service/bubbles/+/local_users/*"
{
    capabilities = ["create","update"]
}

path "paaas/data/service/bubbles/+/auth_key/*"
{
    capabilities = ["read","create","update"]
}

path "paaas/metadata/*"
{
    capabilities = ["list"]
}
```

- <span class="text-purple">paaas-service-user-ro</span>:

```hcl
path "paaas/data/service/squads/*"
{
    capabilities = ["read"]
}

path "paaas/metadata/*"
{
    capabilities = ["list"]
}
```

- <span class="text-cian">paaas-service-role-ro</span>:

```hcl
path "paaas/data/service/squads/user_list/*"
{
    capabilities = ["read"]
}

path "paaas/data/service/squads/targets_list/*"
{
    capabilities = ["read"]
}

path "paaas/metadata/*"
{
    capabilities = ["list"]
}
```

- <span class="text-red">paaas-awxdata-ro</span>:

```hcl
path "paaas/data/app_role/*"
{
    capabilities = ["read"]
}
```
### user access

- <span class="text-yellow">SYS Squad</span>:

```hcl
path "paaas/data/service/bubbles/+/auth_key/*"
{
    capabilities = ["read"]
}

path "paaas/data/service/squads/ssh_key/sys/*"
{
    capabilities = ["read","create","update"]
}

path "paaas/metadata/*"
{
    capabilities = ["list"]
}
```

To use the playbook `deploy-ssh-key.yml` from sys-catalogue-service, they need to use an approle with policy.

``` hcl
path "paaas/data/service/bubbles/+/auth_key/*"
{
    capabilities = ["read"]
}
```

- <span class="text-pink">PAAAS Squad</span>

```hcl
path "paaas/data/*"
{
    capabilities = ["read","create","update","delete"]
}

path "paaas/metadata/*"
{
    capabilities = ["list"]
}
```

## Structure

### paaas/app_role

On this path `paaas/app_role` we found the differents app_roles defined for paaas service provisionning:

- <span class="text-blue">paaas-service-init-r</span>:
- <span class="text-corail">paaas-service-init-w</span>
- <span class="text-purple">paaas-service-user-ro</span>
- <span class="text-cian">paaas-service-role-ro</span>
- <span class="text-red">paaas-awxdata-ro</span>:

Each app_role is defined as the following template:

``` json
    {
        "role_id": "XXXX",
        "secret_id": "XXXX"
    }
```

### paaas/service

On this path `paaas/service`, we have secrets/config needed by paaas service provisionning.
</br>The config available in the vault are added to vault to avoid duplication configuration and be sure that all bubble use the same configuration.

#### `paaas/service/squads/user_list/{ squad_name }`

On this path, { squad_name } are: paaas, sys.
On these secret, an json object is defined using the template below with all squad user:

```json
    {
        "squad_name": [
            {
                "username": "XXXXX",
                "email": "XXXX@XXXX.XXXX",
            },
            {
                "username": "YYYYY",
                "email": "YYYY@YYYYY.YYYYY"
            }
        ]
    }
```

#### `paaas/service/squads/targets_list/{ squad_name }`

On this path, { squad_name } are: paaas, sys.
On these secret, an json object is defined using the template below with all squad user:

```json
    {
        "squad_name": [
            "agent.int"
        ]
    }
```

#### `paaas/service/squads/ssh_key/{ squad_name }/{ username }`

On this path:

- `{ squad_name }` are: `paaas`, `sys`
- `{ username }` are the username defined on `paaas/service/squads/user_list/{ squad_name }`

Each user provide a ssh public_key, and this public key is saved on this path on this following format:

```json
{
    "ssh_key": "ssh-rsa XXXXX====="
}
```

#### `paaas/service/bubbles/{ bubble_name }/auth_key/warpgate`

On this path, for each `bubble_name`, we will store the warpgate public key which will fetch by sys to be installed on the targets as authorized_key for snet user.

#### `paaas/service/bubbles/{ bubble_name }/local_users`

This path contains 4 child paths for the moment:

- warpgate with admin password and admin token as secret
- nodered with admin & api passwords & url as secret
- netbox with admin token & url as secret

and also in this path: `paaas/service/bubbles/{ bubble_name }/local_users/squad_users/{ squad_name }`

- squads users with their initial password as secret

As we don't have for the moment to sent to users their password, a new paths as been added: `paaas/service/bubbles/{ bubble_name }/local_users/squad_users/{ squad }/{ username }` with `{ "password": "XXXXX" }` as secret

#### `paaas/service/global/`

This path contains 5 child paths:

- registry with registry password, image, url and user as secret
- production with version as secret (and all futur global variables)
- paaas_app_vars with variable to create a paaas app as secret
- nodered_vars with variable to create a paaas nodered as secret
- hurl_vars with variable to create a paaas hurl as secret
