# **PAAAS Service Definition**

## **1. Overview**

A **PAAAS** is a **hardened access service** that provides **secure access** to private network resources, typically for administrative (Privileged Users') tasks. It serves as an entry point for SSH, RDP or HTTPS administrative accesses to resources within a **private subnet**.
It will bascically provide a **Bastion Host** service for securely managing deployed resources.

## **2. Objectives**

- Secure access to internal servers and Management interfaces. The target resources will not need anymore to be directly reacheable.
- Enforce least privilege access for administrators.
- Enforce Privileged Accesses compliance requirements.
- Centralize access logging, monitoring and auditing.
- Reduce attack surface on internal networks.

## **3. Architecture**

### **3.1 Deployment Model**

- **Cloud-ready:** DC, COP, AWS EC2, Azure VM, OVH.
- **Network Placement:** Public or Private subnet with access to internal "management" subnets.
- **Access Methods:** Initially SSH (Linux), in the future RDP (Windows) and HTTPS (for Privileged management console).
- **Authentication:** IAM, MFA.

### **3.2 Security Measures**

- **Firewall Rules:**
  - Allowlist specific IPs (Admin Workstations).
  - Restrict service's exposed ports
  - Restrict outbound traffic to internal subnets.
- **Hardened OS:**
  - Disable unnecessary services.
  - Enforce patching and updates.
  - Will rely on SYS standard services
- **Auditing & Logging:**
  - Enable session recording (AWS Systems Manager Session Manager, Azure Bastion, etc.).
  - Store logs in **SIEM** (e.g., AWS CloudTrail, Azure Monitor, Splunk).

## **4. Access Control**

- **Users:**
  - Only authorized administrators.
  - Accesses granted based on groups and user's group membership
  - Groups will provide access based on Squad requirement/responsabilities
- **Authentication Mechanisms (frontend):**
  - MFA
  - EULOGIN IAM roles.
- **Authentication Mechanisms (backend):**
  - SSH keys (Linux) or RDP MFA (Windows).
- **Session Management:**
  - Auto-logoff inactive sessions.
  - Rotate credentials regularly.

## **5. Operations & Maintenance**

- **Service deployment**
  - Service deployment is automated
  - Groups, users and targets management is exposed through primitives, allowing automated configuration. It allows fully automatic deployment, based on business/compliance rules and CMDB content.
- **Group management**
  - Groups definitions has been defined and evolve based on compliance gouvernance
- **User Management**
  - Users to be created/assigned to groups based on Compliance's PUMA process
- **Patching & Updates:**
  - Apply security patches regularly.
- **Monitoring & Alerts:**
  - Detect failed login attempts.
  - Monitor SSH/RDP session activity.
- **Backup & Recovery:**
  - Take snapshots of the bastion host.
  - Maintain an alternate access mechanism (e.g., secondary bastion).

## **6. Compliance & Policies**

- Comply with **DIGIT C4 QPC and COMPLIANCY** guidelines.
- Regular **penetration testing** and **vulnerability scans**.
- Access reviews every **90 days**.

## **7. Decommissioning**

- **Backup Logs & Artifacts** before termination.
- **Remove access keys and credentials**.
- **Destroy VM securely** following cloud provider best practices.

---
This **service definition** ensures **security, compliance, and operational efficiency** for a **PAAAS** (in a DIGIT environment).
