# Operation - Upgrade PAAAS product

This documentation will be describe the process to upgrade the PAAaS product `Warpgate`.

## Create a new branch

As the main branch of the Paaas project is protected, you need to create new branch (from main branch) and checkout into the new branch:

``` bash
  git checkout -b "new_branch_name"
```

Of course, you can also create the branch directly into the gitlab web.

``` mermaid
%%{init: {'theme': 'dark'}}%%
gitGraph
  commit "Merge branch '214-Upgrade-Warpgate-version'"
  branch "234-Upgrade-Warpgate-image-with-v0.20.2"
  checkout "234-Upgrade-Warpgate-image-with-v0.20.2"

```

## Update the Dockerfile

To upgrade, you need to update the `Dockerfile` into the `warpgate` folder of the PAAAS project:

- Change the `WARPGATE_VERSION` variable
- Change the `WARPGATE_RELEASE_DATE` variable with the release date of the warpgate version
- Increase the `PAAAS_VERSION` variable

``` diff
-ARG WARPGATE_VERSION="v0.19.1"
-ARG WARPGATE_RELEASE_DATE="2026-01-05"
-ARG PAAAS_VERSION="0.1.10"
+ARG WARPGATE_VERSION="v0.20.2"
+ARG WARPGATE_RELEASE_DATE="2026-02-06"
+ARG PAAAS_VERSION="0.1.11"
```

Then commit your change

``` bash
git commit -m "update version"
```

``` mermaid
%%{init: {'theme': 'dark'}}%%
gitGraph
  commit "Merge branch '214-Upgrade-Warpgate-version'"
  branch "234-Upgrade-Warpgate-image-with-v0.20.2"
  checkout "234-Upgrade-Warpgate-image-with-v0.20.2"
  commit id: "update version"
```

## Test into the lab/local-ci

If you have a gilab-local-ci, firstly test into your local-ci the pipeline.

### build the new images

``` bash
gcl --stage build-paaas
.
.
.
 PASS  [  8.6 s] build-warpgate-build                       
 PASS  [ 6.67 s] build-hurl-build-paaas                     
 PASS  [   13 s] build-nodered-build                        
 PASS  [ 5.46 s] vault-populate-secrets-json       

```

### Test the new images into the CI

``` bash
gcl --stage test-build-paaas
.
.
.
 PASS  [ 7.71 s] run-warpgate-build                         
 PASS  [ 9.22 s] run-nodered-paaas-build                    
 PASS  [ 4.44 s] build-hurl                                 
 PASS  [ 3.06 s] test-warpgate-build                        
 PASS  [ 3.79 s] test-nodered-build                         
 PASS  [1.22 min] test-hurl-build-paaas-test                 
 PASS  [ 9.43 s] tag-and-deploy-build-image                 
 PASS  [ 6.26 s] tag-and-deploy-build-hurl                  
 PASS  [   17 s] tag-and-deploy-build-nodered               
pipeline finished in 1.9 min
```

### Clean the test & deploy the environmemt to test the service

``` bash
gcl --stage build-test-env-build
.
.
.
 PASS  [   18 s] clean-pre-deploy-netbox
 PASS  [   34 s] clean-pre-test-deploy-paaas-service
 PASS  [ 2.43 s] deploy-netbox
 PASS  [1.98 min] configure-netbox
 PASS  [  3.7 s] build-and-start-vault-build
 PASS  [ 6.89 s] download-vault-vars-build
 PASS  [  23 ms] create-env-variables
```

### Test the service

``` bash
gcl --stage test-build-paaas-service
.
.
.
 PASS  [ 3.09 s] debug-ci                                   
 PASS  [   20 s] create-paaas-build-netbox-secrets          
 PASS  [   18 s] create-paaas-build-admin-password          
 PASS  [   20 s] create-paaas-build-nodered-secrets         
 PASS  [1.3 min] test-deploy-paaas-build-service            
 PASS  [1.1 min] test-deploy-nodered-paaas-build-service    
 PASS  [3.27 min] test-deploy-hurl-build-service             
 PASS  [1.2 min] test-update-paaas-build-service            
 PASS  [   60 s] test-update-nodered-paaas-build-service    
 PASS  [4.23 min] test-update-hurl-build-service             
 PASS  [3.85 min] test-build-paaas-service                   
 PASS  [   15 s] test-deploy-token-in-paaas-build           
 PASS  [   12 s] save-paaas-build-public-key                
 PASS  [   31 s] test-create-targets-build                  
 PASS  [   35 s] test-create-users-build                    
 PASS  [   29 s] test-create-roles-build 
```

### Clean

``` bash
gcl --stage clean
.
.
.
 PASS  [   21 s] clean-netbox                               
 PASS  [ 5.27 s] post-clean-netbox                          
 PASS  [   20 s] clean-exporter                             
 PASS  [ 3.81 s] clean-vault-build                          
 PASS  [ 2.73 s] clean-test-paaas-build                     
 PASS  [ 8.73 s] clean                                      
 PASS  [ 4.78 s] local-clean
```

## Push to run the pipeline into the gitlab runner

To run the pipeline with the new version of the warpgate, you need to push your change.

``` bash
git push
```

Then the pipeline starts and should finish with success.

![PAAAS_pipeline](./images/pipeline-after-the-upgrade.png)

## Create Merge Request to push the new version into the main branch

Into the gitlab, you can create the merge request like [Merge146](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/merge_requests/146)

Ensure the CI pipeline completes successfully before requesting review.

Once the merge is approved, you can merge the branch to the main, and the new version is deployed

``` mermaid
%%{init: {'theme': 'dark'}}%%
gitGraph
  commit
  branch "234-Upgrade-Warpgate-image-with-v0.20.2"
  checkout "234-Upgrade-Warpgate-image-with-v0.20.2"
  commit id: "update version"
  checkout main
  merge "234-Upgrade-Warpgate-image-with-v0.20.2" id: "Upgrade Warpgate to v0.20.2"
```

Ensure the CI pipeline of the merge request completes successfully
