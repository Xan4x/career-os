# SSH Access - User Guide

Warpgate is the PAAAS service for SSH access to the bubble servers.

All target are created based on the name of the vm as described on netbox `https://netbox.<RPS_Tech_NMS_fqdn>/virtualization/virtual-machines/`

![VM PAAAS](images/VM-netbox-paaas.png)

By *Default*, `SYS` have access to all bubble servers.
Anothers squad roles are not yet defined.

## Welcome workstations

As describe on the [SSH access design][PAAS_access_design], to connect to a bubble server from Welcome laptop you need use the "Cloud" proxy.

All needed seetings to connect to a target are described below:

```bash
hostname: warpgate.<Bubble_RPS_Tech_NMS_fqdn>
port 3022
username: <UserName>:<target_name>
Connection:
    proxy:
        proxy_hostname: <proxy_cloud_hostname>
        port: 8012
        proxy_type : Telnet
        proxy_command: CONNECT %host:%port HTTP/1.1\r\nHost: %host:%port\r\nProxy-Authorization: Basic <username:password|base64>\r\nUser-Agent: Warpgate\r\n\r\n
    SSH:
        Auth: 
            Private key file for authentication: <private_key_with_path>
```

### PUTY - Session seetings

So to configure a connection to a target with Putty, you need to create a new session like descirbe below:

#### Create a session

![putty_session](images/putty_session.png)

1. Hostname: `warpgate.<Bubble_RPS_Tech_NMS_fqdn>`
2. Port: `3022`
3. Connection type: `SSH`
4. Saved session: name to save the session, you can put `<UserName>:<target_name>@warpgate.<bubble>`

#### Data configuration

![putty_session_data](images/putty_session_data.png)

Auto-login username: `<UserName>:<target_name>`

#### Proxy configuraton

![putty_session_proxy](images/putty_session_proxy.png)

1. Proxy type: `Telnet`
2. Proxy hostname: `<proxy_cloud_hostname>`
3. Port: `8012`
4. Telnet command, or local proxy command: `CONNECT %host:%port HTTP/1.1\r\nHost: %host:%port\r\nProxy-Authorization: Basic <username:password|base64>\r\nUser-Agent: Warpgate\r\n\r\n`

#### SSH Auth configuration

![putty_session_ssh_auth](images/putty_session_ssh_auth.png)

Private key file for authentication: `<path_of_your_private_key>`

### Connection

Once you session is configured, you can open a connection:

![putty_session_connection](./images/putty_session_connection.png)

1. First authentication requested: your key's passphrase
2. Secondly the OTP,
3. And to finish, your password

After that, you are connected to the target with snet user, and your session is recorded

## L4D Workstation

As describe on the [SSH access design][PAAS_access_design], to connect to a bubble server from L4D laptop you need use the "Cloud legacy" proxy.

All needed seetings to connect to a target are described below:

```bash
hostname: warpgate.<Bubble_RPS_Tech_NMS_domain>
port 3022
username: <UserName>:<target_name>
proxy_command: ProxyCommand nc -P <username> -X connect -x <proxy_cloud_hostname>:8012 %h %p
```
### Connection

You can connect to a target using the following ssh connection:

``` bash
ssh -o "ProxyCommand nc \
       -P <username> \
       -X connect \
       -x <proxy_cloud_hostname>:8012 %h %p" \
    -i <path_of_your_private_key>/<key> \
    "<username>:<target>@warpgate.<Bubble_RPS_Tech_NMS_domain>" \
    -p 3022
```

![connection_from_L4D](images/connection_from_L4D.png)

#### example

``` bash
ssh -o "ProxyCommand nc \
       -P blaisau \
       -X connect \
       -x pslux-vip-cloud-legacy.tech.ec.europa.eu:8012 %h %p" \
    -i ~/.ssh/blaisau-l4d \
    "blaisau:ras.ec.local@warpgate.paaas.nms.tech.ec.europa.eu" \
    -p 3022
```

[PAAS_access_design]: ./PAAAS_access_design.md
