# PAAAS Project Overview

## What is Platform Authentication As A Service ?

- PAAAS is a **bastion service** through which users connect to internal resources
- It acts as a **secure gateway** for accessing SSH targets located in AWS BUBBLES
- All access is **controlled, audited**
- Users do **not connect directly** to target machines — they go through PAAAS
- The service enforces **security policies, access control and session monitoring**

![PAAAS_service](images/whatispaaas.png)

## Why PAAAS ?

### Access Management

- Access to SSH targets through the PAAAS service is **strictly managed** based on **predefined roles**
- Each user is assigned a role which determines which targets they can access

### Session Recording

To ensure **security and accountability, all SSH sessions are recorded**
These recordings serve multiple purposes:

- **Audit trails** for compliance and internal reviews
- **Transparency and traceability** of all operations performed on critical systems
- **Post-incident analysis** in case an alert is triggered

## MVP

### Definition

Provide secured, controlled and audited SSH connections through PAAAS to SYS administrators in the BUBBLES located in AWS

Deliverables :

- [Service and operations (primitives) definition][Openapi]
- [MoSCoW table definition and Product evaluation][Moscow]
- Automated deployment of selected product in the BUBBLES located in AWS

### Limitation

- No Self-service request​
- Only SSH service will be enabled​
- Authentication managed locally​
- Access restricted to SYS team only

## PAAAS service components

![PAAAS_components_overview](./images/PAAAS_components_overview.png)

- <span class="text-paaas"> PAAAS </span>: Warpgate product with custom prometheus exporter to expose custom <span class="text-metric"> METRICS </span>
- <span class="text-prim"> PRIMITIVES </span>: Node-Red to expose Business Primitive
- <span class="text-test"> TEST </span>: Hurl to test the PAAAS service: Warpgate & Node-Red

## Progress So Far

- MVP scope and deliverable clearly defined
- Product evaluated
- MoSCoW table completed for all included in the product items.
- Business Primitives defined
- Access control model defined for SYS team
- CI/CD pipeline designed and partially implemented 🚧
- Automated build & test of service components into CI/CD
- Automated deployment tested in AWS Bubbles (only PAAAS acceptance) 🚧
  - deployement of the paaas service

## High/Level CI/CD overview

![pipeline](./images/pipeline.png)

- Code Quality Checks
  - Code review for Ansible & Go
  - Linting and duplication detection
- Business Primitive & Documentations build & deployed
- Custom Warpgate image: includes warpgate-exporter binary, build, tested & deployed
- Custom Hurl image for PAAAS: build, tested & deployedCode Quality Checks
- Custom Node-Red image for PAAAS: build, tested & deployed
- Deployment & Testing of Targets, Users, Roles
- Deployment of the PAAAS service, composed of the three images, to Acceptance PAAAS Bubble
- Deployment & Testing of Target, Users, Roles (production values) into Acceptance PAAAS Bubble
- Functional testing of PAAAS service components performed after deployment to the Acceptance Bubble

## Remaining work MVP (2026-03-11)

- Create the deployment of the PAAAS Service with AWX DATA
- Deploy the PAAAS service in AWS BUBBLES
- Complete documentations of the PAAAS service
- Create SOPs for service operations
- Implement Alerting
- Create SOPs for alert handling
- Compliance check with advanced alerting and anomaly detection
- Improve CI to include compliance checks based on MoSCoW requirements

[todolist][todolist]

## Future enhancements & features (2026-03-11)

### Planned for later implementation

- Extend access beyond SYS team
- Create credential process
- Monitoring (pending deployment of the Grafana in Bubbles)
  - Creation of PAAAS dashboard & graphs
  - Improve alerting mechanisms & create/update SOPs for alerting handling

### Topics discussed but not yet defined

- Integrate external IAM
- Integration with Compliance’s PUMA process for user lifecycle
- Define a data model using CMDB instead of config contexts
- Improve credential policy (e.g., rotation, expiration, strength)

[Moscow]: ./moscow.md
[Openapi]: ./openapi.html
[todolist]: ./deploiement_paaas_on_bubbles_todo_list.md
