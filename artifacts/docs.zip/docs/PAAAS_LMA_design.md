# PAAAS logging, monitoring & alerting design

This documentation describe the design of logging, monitoring & alerting for PAAAS service.

## Monitoring

```mermaid

    flowchart TD

        subgraph VM["☁️🖥️ PAAAS VM"]
            Exporter(":::9241 LISTEN")
            subgraph Container["📦 Warpgate"]
                App("🚀 Warpgate")
                Metrics("📊 Warpgate-exporter")
            end
        end

        subgraph PromVM["☁️🖥️ Monitoring VM"]
            PromList(":::9090 LISTEN")
            BBList(":::9195 LISTEN")
            subgraph PromCont["📦 Prometheus"]
                appProm("🚀 :::9090")
            end
            subgraph BBCont["📦 BlackBox"]
                appBB("🚀 :::9195")
            end
        end

        subgraph NetboxVM["☁️🖥️ Netbox VM"]
            netbox(":::8080 LISTEN")
            subgraph NetboxCont["📦 Netbox"]
                NetboxApp("🗄️ :::8080")
            end
        end

        classDef blockStyle fill:#474949,stroke:#6D6E6E,stroke-width:2px,color:#FFFFFF;
        classDef caseBlockStyle fill:#1F2020,stroke:#C7C7C7,color:#d0d0d0,stroke-width:2px;
        classDef caseStyle fill:#1F2020,stroke:#C7C7C7,color:#d0d0d0,stroke-width:2px;

        class VM,Container,NetboxVM,PromVM,PromCont,NetboxCont,BBCont blockStyle
        class App,Metrics,Exporter,appProm,appBB,netbox,PromList,BBList,NetboxApp caseBlockStyle
        class RPS,W,P,F,L caseStyle

        %% Monitoring 

        PromCont --> | TCP_9241| Exporter
        Exporter --> | TCP_9241| Metrics
        Metrics --> | TCP_8888 | App

        W(Welcome 💻) -->| HTTPS | P("🧩 Proxy T2 Cloud<br>🧱 FW4")
        P --> | HTTPS | L(☁️🔀 Bubble Private LB)
        L --> | HTTPS | RPS("☁️🔁 RPS <br> prometheus mapping")
        RPS --> |9090| PromList
        PromList --> |9090| appProm


        PromCont --> |8080| netbox
        netbox --> |8080| NetboxApp

        appBB --> BBList
        BBList --> VM
        PromCont --> BBList

        W --> |TCP_9090| P
        P --> |TCP_9090| L
        L --> |9090| PromList

        %% Color Monitoring
        linkStyle 0 stroke:#d7a21e,stroke-width:2px
        linkStyle 1 stroke:#d7a21e,stroke-width:2px
        linkStyle 2 stroke:#d7a21e,stroke-width:2px

        linkStyle 3 stroke:#108989,stroke-width:2px
        linkStyle 4 stroke:#108989,stroke-width:2px
        linkStyle 5 stroke:#108989,stroke-width:2px
        linkStyle 6 stroke:#108989,stroke-width:2px
        linkStyle 7 stroke:#108989,stroke-width:2px

        linkStyle 8 stroke:#0e68f7,stroke-width:2px
        linkStyle 9 stroke:#0e68f7,stroke-width:2px

        linkStyle 10 stroke:#a870fd,stroke-width:2px
        linkStyle 11 stroke:#a870fd,stroke-width:2px
        linkStyle 12 stroke:#a870fd,stroke-width:2px

        linkStyle 13 stroke:#8f0a3c,stroke-width:2px
        linkStyle 14 stroke:#8f0a3c,stroke-width:2px
        linkStyle 15 stroke:#8f0a3c,stroke-width:2px
        



```

The PAAAS VM is monitoring like all VM on AWS by Sys team.
<br>The PAAAS Service is monitoring with Prometheus & the exporter metrics available on the Warpgate container.

Prometheus check on netbox all VM tags. The target list of the PAAAS service is automaticly created/updated: the VMs with tag `warpgate_monitoring`.

On the bubble PAAAS, the `prometheus.<Bubble_RPS_Tech_NMS_fqdn>` is available from Welcome workstation.
<br> Direct access to the prometheus server is available on the port 9090 from Welcome workstation on the LB-private.

All details of the Warpgate-exporter is available on the README on the folder Warpgate-exporter of the C4/PAAAS project.

But you can found an extract of the metrics below:

``` bash

# HELP warpgate_auth_tickets Warpgate tickets
# TYPE warpgate_auth_tickets gauge
warpgate_auth_tickets 1
# HELP warpgate_auth_tickets_target Warpgate tickets per target
# TYPE warpgate_auth_tickets_target gauge
warpgate_auth_tickets_target{target="perdu.com"} 1
# HELP warpgate_auth_tickets_user Warpgate tickets per user
# TYPE warpgate_auth_tickets_user gauge
warpgate_auth_tickets_user{username="ticket-01"} 1
# HELP warpgate_sessions Warpgate sessions
# TYPE warpgate_sessions gauge
warpgate_sessions 1
# HELP warpgate_sessions_proto Warpgate sessions per protocol
# TYPE warpgate_sessions_proto gauge
warpgate_sessions_proto{protocol="HTTP"} 1
# HELP warpgate_sessions_user Warpgate session per user
# TYPE warpgate_sessions_user gauge
warpgate_sessions_user{username="admin"} 1
# HELP warpgate_targets Warpgate Targets defined
# TYPE warpgate_targets gauge
warpgate_targets 10
# HELP warpgate_targets_name Warpgate Targets per name defined
# TYPE warpgate_targets_name gauge
warpgate_targets_name{name="netbox-test-ssh"} 1
warpgate_targets_name{name="warpgate:admin"} 1
# HELP warpgate_targets_type Warpgate Targets per type defined
# TYPE warpgate_targets_type gauge
warpgate_targets_type{type="Ssh"} 1
warpgate_targets_type{type="WebAdmin"} 1
# HELP warpgate_users Warpgate Users defined
# TYPE warpgate_users gauge
warpgate_users 3
# HELP warpgate_users_bad_policy Warpgate Total of Users with bad policy defined
# TYPE warpgate_users_bad_policy gauge
warpgate_users_bad_policy 1
# HELP warpgate_users_with_bad_policy Warpgate Users with bad policy defined
# TYPE warpgate_users_with_bad_policy gauge
warpgate_users_with_bad_policy{username="test-api-user"} 1
```

## Alerting

```mermaid

    flowchart TD

        subgraph VM["☁️🖥️ PAAAS VM"]
            Exporter(":::9241 LISTEN")
            subgraph Container["📦 Warpgate"]
                App("🚀 Warpgate")
                Metrics("📊 Warpgate-exporter")
            end
        end

        subgraph PromVM["☁️🖥️ SYS VM"]
            AlertMList(":::9093 LISTEN")
            subgraph PromCont["📦 Prometheus"]
                appProm("🚀 :::9090")
            end
            subgraph AlertMCont["📦 Alert Manager"]
                appAlertM("🚀 :::9093")
            end
            subgraph BBCont["📦 BlackBox"]
                appBB("🚀 :::9195")
            end
        end

        classDef blockStyle fill:#474949,stroke:#6D6E6E,stroke-width:2px,color:#FFFFFF;
        classDef caseBlockStyle fill:#1F2020,stroke:#C7C7C7,color:#d0d0d0,stroke-width:2px;
        classDef caseStyle fill:#1F2020,stroke:#C7C7C7,color:#d0d0d0,stroke-width:2px;

        class VM,Container,PromVM,PromCont,AlertMCont,BBCont blockStyle
        class App,Metrics,Exporter,AlertMList,appProm,appAlertM,appBB caseBlockStyle
        class RPS,W,P,F,L caseStyle

        %% Alerting

        PromCont --> | TCP_9241| Exporter
        Exporter --> | TCP_9241| Metrics
        Metrics --> | TCP_8888 | App

        appBB --> VM
        BBCont --> AlertMList
        PromCont --> AlertMList

        AlertMList --> |TCP_9093| appAlertM
        AlertMCont --> L(☁️🔀 Bubble Private LB)
        L --> F(🧱 FW4)
        F --> S("SMART")

        W(Welcome 💻) -->| TCP_9093 | P(🧩 Proxy T2 Cloud)
        P --> | TCP_9093 | F(🧱 FW4)
        F --> | TCP_9093 | L(☁️🔀 Bubble Private LB)
        L --> |TCP_9093| AlertMList

        %% Color Alerting
        linkStyle 0 stroke:#d7a21e,stroke-width:2px
        linkStyle 1 stroke:#d7a21e,stroke-width:2px
        linkStyle 2 stroke:#d7a21e,stroke-width:2px

        linkStyle 3 stroke:#8f0a3c,stroke-width:2px

        linkStyle 4 stroke:#a870fd,stroke-width:2px
        linkStyle 5 stroke:#a870fd,stroke-width:2px
        linkStyle 6 stroke:#a870fd,stroke-width:2px
        linkStyle 7 stroke:#a870fd,stroke-width:2px
        linkStyle 8 stroke:#a870fd,stroke-width:2px
        linkStyle 9 stroke:#a870fd,stroke-width:2px

        linkStyle 10 stroke:#1ecfff,stroke-width:2px
        linkStyle 11 stroke:#1ecfff,stroke-width:2px
        linkStyle 12 stroke:#1ecfff,stroke-width:2px
        linkStyle 13 stroke:#1ecfff,stroke-width:2px

```

There is no specific alert for the PAAAS service for the moment, but they will follow the Alerting flow set by the Supporting Service team as describe on the diagram.

## Logging

```mermaid

    flowchart TD

        subgraph VM["☁️🖥️ PAAAS VM"]
            rsyslog(":::10514 LISTEN <br>rsyslog")
            subgraph Container["📦 Warpgate"]
                App("🚀 Warpgate")
                Metrics("📊 Warpgate-exporter")
            end
        end

         subgraph SysVM["☁️🖥️ Syslog VM"]
            syslog-ng(":::514 LISTEN")
            subgraph SysCont["📦 Syslog"]
                sysApp("📜 :::514")
            end
        end


        classDef blockStyle fill:#474949,stroke:#6D6E6E,stroke-width:2px,color:#FFFFFF;
        classDef caseBlockStyle fill:#1F2020,stroke:#C7C7C7,color:#d0d0d0,stroke-width:2px;
        classDef caseStyle fill:#1F2020,stroke:#C7C7C7,color:#d0d0d0,stroke-width:2px;

        class VM,Container,SysVM,SysCont blockStyle
        class App,Metrics,Exporter,syslog-ng,sysApp,rsyslog caseBlockStyle
        class RPS,W,P,F,L caseStyle
     
        
        %% Logging

        Container --> |stdout<br>UDP_10514| rsyslog
        rsyslog -->  |UDP_514 | syslog-ng
        syslog-ng -->  |UDP_514 | sysApp
        SysVM --> |UDP_514| LB(☁️🔀 Bubble Private LB)
        LB --> |UDP_514| Az12("☁️AZ1 && AZ2")
        Az12 --> |TLS-6154| SysCent("Central syslog")

        %% Color Logging
        linkStyle 0 stroke:#a870fd,stroke-width:2px
        linkStyle 1 stroke:#1E90FF,stroke-width:2px
        linkStyle 2 stroke:#1E90FF,stroke-width:2px
        linkStyle 3 stroke:#1E90FF,stroke-width:2px
        linkStyle 4 stroke:#1E90FF,stroke-width:2px
        linkStyle 5 stroke:#1ecfff,stroke-width:2px

```

The logging of the PAAAS service (Warpgate container including warpgate application & promtheus exporter) is sent to stdout.
<br> So use the default service provide by Supporting services to sent our logs to the central serveurs.
<br> The logs is saved on the file `<default_daily_path>/ras/warpgate.log` on the central server.

There is mtail configuration has been created on the central servers: `http://<mtail_hostname>:3919/`
<br>And it is monitored by the central pometheus: `<central_prometheus_hostname>/targets?search=&scrapePool=mtail_warpgate`
