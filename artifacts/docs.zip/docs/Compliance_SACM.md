# Service asset and configuration management

This document describe the implementation of the requirement [sacm-vuln-cmdb][sacm-vuln-cmdb]
As the [vulnerability orchestrator][sacm-vuln-archi] will fetch all netbox, we need to have the same configuration, formats for each sacm-vuln properties into the CMDB

## Implementation into Netbox

The properties are required:

| Property | NetBox Field           | Purpose                     |
| -------- | ---------------------- | --------------------------- |
|  Vendor  | Device / Device Type   | Manufacturer identification |
|  Product | Device Type            | Product identification |
|  Version | Custom Field (Release) | Firmware / OS version |
| End of Sale | Custom Field (EOS) | Commercial lifecycle |
| End of Support | Custom Field (EOL) | Security lifecycle |
| Version Release date | Version Release date | Release date of the version installed |

These properties need to be available into all netbox object listed below:

- `dcim.device`
- `dcim.platform`
- `dcim.module`
- `dcim.service`
- `netbox_docker_plugin.image`

The [documentation][sacm-vuln-cmdb] explain depending the case which object to field

### Vendor

If not available into netbox, you need to create a new custom field named "Vendor" into all netbox object above:

- name: `Vendor`
- Content types:
  - `DCIM > Device`
  - `DCIM > Platform`
  - `DCIM > Module`
  - `IPAM > Service`
  - `NetBox Docker Plugin > Image`
- Type: `Object`
- Object type: `DCIM > Manufacturer`

To create it, you can post the following payload to the netbox api point: `/api/extras/custom-fields/`

```json
{
 "content_types": [
        "dcim.device",
        "dcim.platform",
        "dcim.module",
        "ipam.service",
        "netbox_docker_plugin.image"
      ],
  "type": "object",
  "object_type": "dcim.manufacturer",
  "name": "Vendor"
}
```

For the moment we don't enable "required" as it will be impact all objects into "content_type" into all netbox…

You can get with the netbox API your asset and found the Vendor into the Custome field:

``` json
  "custom_fields": {
      "Vendor": {
        "id": 1,
        "url": "http://192.168.1.54:8000/api/dcim/manufacturers/1/",
        "display": "Warptech Industries",
        "name": "Warptech Industries",
        "slug": "warptech-industries"
      }
    }
```

### Product

If not available into netbox, you need to create a new custom field named "Vendor" into all netbox object above:

- name: `Product`
- Content types:
  - `DCIM > Device`
  - `DCIM > Platform`
  - `DCIM > Module`
  - `IPAM > Service`
  - `NetBox Docker Plugin > Image`
- Type: `Object`
- Object type: `DCIM > Device Type`

To create it, you can post the following payload to the netbox api point: `/api/extras/custom-fields/`

```json
  {
  "content_types": [
          "dcim.device",
          "dcim.platform",
          "dcim.module",
          "ipam.service",
          "netbox_docker_plugin.image"
        ],
    "type": "object",
    "object_type": "dcim.devicetype",
    "name": "Product"
  }
```

For the moment we don't enable "required" as it will be impact all objects into "content_type" into all netbox…

You can get with the netbox API your asset and found the Vendor into the Custome field:

``` json
  "custom_fields": {
    "Product": {
      "id": 1,
      "url": "http://192.168.1.54:8000/api/dcim/device-types/1/",
      "display": "warpgate",
      "manufacturer": {
        "id": 1,
        "url": "http://192.168.1.54:8000/api/dcim/manufacturers/1/",
        "display": "Warptech Industries",
        "name": "Warptech Industries",
        "slug": "warptech-industries"
      },
      "model": "warpgate",
      "slug": "warpgate"
    },
    "Vendor": {
      ..
    }
  }
```

### Release (Version)

- name: `Release`
- Content types:
  - `DCIM > Device`
  - `DCIM > Platform`
  - `DCIM > Module`
  - `IPAM > Service`
  - `NetBox Docker Plugin > Image`
- Type: `Text`

To create it, you can post the following payload to the netbox api point: `/api/extras/custom-fields/`

``` json
  {
  "content_types": [
          "dcim.device",
          "dcim.platform",
          "dcim.module",
          "ipam.service",
          "netbox_docker_plugin.image"
        ],
    "type": "text",
    "name": "Release"
  }
```

For the moment we don't enable "required" as it will be impact all objects into "content_type" into all netbox…

### Version Release date

- name: `Release_date`
- Content types:
  - `DCIM > Device`
  - `DCIM > Platform`
  - `DCIM > Module`
  - `IPAM > Service`
  - `NetBox Docker Plugin > Image`
- Type: `Text`
- Required: `false`

To create it, you can post the following payload to the netbox api point: `/api/extras/custom-fields/`

``` json
  {
  "content_types": [
          "dcim.device",
          "dcim.platform",
          "dcim.module",
          "ipam.service",
          "netbox_docker_plugin.image"
        ],
    "type": "date",
    "name": "Release_date"
  }
```

For the moment we don't enable "required" as it will be impact all objects into "content_type" into all netbox…

### End of Sale (EOS)

- name: `EOL`
- Content types:
  - `DCIM > Device`
  - `DCIM > Platform`
  - `DCIM > Module`
  - `IPAM > Service`
  - `NetBox Docker Plugin > Image`
- Type: `Date & Time`

To create it, you can post the following payload to the netbox api point: `/api/extras/custom-fields/`

``` json
  {
  "content_types": [
          "dcim.device",
          "dcim.platform",
          "dcim.module",
          "ipam.service",
          "netbox_docker_plugin.image"
        ],
    "type": "datetime",
    "name": "EOS"
  }
```

### End of Support (EOL)

- name: `EOL`
- Content types:
  - `DCIM > Device`
  - `DCIM > Platform`
  - `DCIM > Module`
  - `IPAM > Service`
  - `NetBox Docker Plugin > Image`
- Type: `Date & Time`

To create it, you can post the following payload to the netbox api point: `/api/extras/custom-fields/`

``` json
  {
  "content_types": [
          "dcim.device",
          "dcim.platform",
          "dcim.module",
          "ipam.service",
          "netbox_docker_plugin.image"
        ],
    "type": "datetime",
    "name": "EOL"
  }
```

## Conformity check

### Properties exists

Vendor, product, release, release_date, EOS, EOL are custom fields availables into the netbox objects below:

- `DCIM > Device`
- `DCIM > Platform`
- `DCIM > Module`
- `IPAM > Service`
- `NetBox Docker Plugin > Image`

This check is a conformity check for CMDB, but until they deploy all custom fields into the new images, we can add this check into our CI.
So into the pipeline, get each object and check the presence and the formats of the custom fields.

### Assets properties field

The purpose of these checks is to define if your assets are compliant.

#### Hardware

- asset available into the netbox as `DCIM > Device` or `DCIM > Module` (if applicable)
- properties Vendor, product, release, release_date, EOS, EOL defined

#### Operating System

- asset available into the netbox as `DCIM > Platform`
- properties Vendor, product, release, release_date, EOS, EOL defined
- asset linked to Host(s)

#### Container Image / Service

- asset available into the netbox as `IPAM > Service` or `NetBox Docker Plugin > Image`
- properties Vendor, product, release, release_date, EOS, EOL defined
  - EOS, EOL can be `null`
- Runtime host relationship defined

- In case of container image, the base image must be identified and can be define as `DCIM > Platform`

## PAAAS implementation

### Definition of the properties into the dockerfile

#### Warpgate

As this image is managed by paaas (we don't fetch a docker image for this product), some change was done into the dockerfile:

- To define the base name, new ARGs was created:

``` diff
+ ARG IMAGE_OS=debian
+ ARG IMAGE_OS_VERSION=trixie-slim

- FROM debian:trixie-slim
+ FROM ${IMAGE_OS}:${IMAGE_OS_VERSION}
```

- To build properties, new ARG & LABELS was added

``` diff
ARG WARPGATE_VERSION="v0.20.2"
+ ARG WARPGATE_RELEASE_DATE="2026-02-06"
ARG PAAAS_VERSION="0.1.12"
```

``` diff
+ LABEL vendor="warpgate_project"
+ LABEL product="warpgate"
LABEL version=${WARPGATE_VERSION}
+ LABEL release_date=${WARPGATE_RELEASE_DATE}
LABEL paaas.warpgate.version=${PAAAS_VERSION}
+ LABEL base.name=${IMAGE_OS}:${IMAGE_OS_VERSION}
```

#### NodeRed

As we use an image from nodered project as base, and we custom the image for paaas, we need to add some information into the image created with dockerfile:

``` diff
+ ARG nodered_version
ARG VERSION_RELEASE_DATE="2025-02-14"

- FROM nodered/node-red:4.0.9
+ FROM nodered/node-red:${nodered_version}

+ ARG nodered_version
+ ARG VERSION_RELEASE_DATE
+ ARG BASE_OS

+ LABEL vendor="nodered"
+ LABEL product="node-red"
LABEL paaas.nodered.version=0.1.10
+ LABEL version=${nodered_version}
+ LABEL release_date=${VERSION_RELEASE_DATE}
+ LABEL base.name=${BASE_OS}
```

But as the base image is nodered/node-red:XXX, we need to fetch the base name into the image, then define with the new arg variabel `BASE_OS`
Into the nodered-build job we create the variable as below, then use it `--build-arg BASE_OS=${BASE_OS}` into the build command.

``` yaml
- BASE_OS=$(docker run --rm --name temp-nodered --entrypoint sh nodered/node-red:${NODERED_VERSION} -c '. /etc/os-release && echo ${ID}:${VERSION_ID}' )
- docker build --build-arg nodered_version="${NODERED_VERSION}" --build-arg BASE_OS=${BASE_OS} -f nodered/Dockerfile ./nodered -t ${CI_REGISTRY_IMAGE}/nodered:${IMAGE_TAG}
```

#### Hurl

For this image, as we create our image from hurl image, we use the label created into the "base image" to generate the properties

### Storage of the properties

Into the pipeline, when we deploy a new version of the project, based on these label, we create a json when we deploy a new version then we deploy these json into the project [paaas_image_registry][paaas_image_registry]

``` mermaid
sequenceDiagram
Gitlab-PAAAS ->> paaas-runner: build image with properties
Gitlab-PAAAS ->> paaas-runner: generate properties
paaas-runner ->> Gitlab-paaas-registry-image: update the json stored into gitlab
```

#### Warpgate json creation

``` yaml
    - docker tag ${CI_REGISTRY_IMAGE}/${APP_NAME}:build ${CI_REGISTRY_IMAGE}/${APP_NAME}:${IMAGE_TAG}
    - docker push ${CI_REGISTRY_IMAGE}/${APP_NAME}:${IMAGE_TAG}
    - APP_VENDOR=$(docker inspect --format='{{ index .Config.Labels "vendor" }}' ${CI_REGISTRY_IMAGE}/${APP_NAME}:${IMAGE_TAG})
    - APP_PRODUCT=$(docker inspect --format='{{ index .Config.Labels "product" }}' ${CI_REGISTRY_IMAGE}/${APP_NAME}:${IMAGE_TAG})
    - APP_VER=$(docker inspect --format='{{ index .Config.Labels "version" }}' ${CI_REGISTRY_IMAGE}/${APP_NAME}:${IMAGE_TAG})
    - APP_VER_DATE=$(docker inspect --format='{{ index .Config.Labels "release_date" }}' ${CI_REGISTRY_IMAGE}/${APP_NAME}:${IMAGE_TAG})
    - APP_BASE_NAME=$(docker inspect --format='{{ index .Config.Labels "base.name" }}' ${CI_REGISTRY_IMAGE}/${APP_NAME}:${IMAGE_TAG})
    - |
      cat <<EOF > paaas-${APP_NAME}-release-${IMAGE_TAG}.json
      {
        "vendor": "${APP_VENDOR}",
        "product": "${APP_PRODUCT}",
        "release": "${APP_VER}",
        "release_date": "${APP_VER_DATE}",
        "base_name": "${APP_BASE_NAME}",
        "image": "${CI_REGISTRY_IMAGE}/${APP_NAME}",
        "image_version": "${IMAGE_TAG}"
      }
      EOF
```

#### Nodered json creation

``` yaml
    - docker tag ${CI_REGISTRY_IMAGE}/nodered:build ${CI_REGISTRY_IMAGE}/nodered:${IMAGE_TAG}
    - docker push ${CI_REGISTRY_IMAGE}/nodered:${IMAGE_TAG}
    - APP_VENDOR=$(docker inspect --format='{{ index .Config.Labels "vendor" }}' ${CI_REGISTRY_IMAGE}/nodered:${IMAGE_TAG})
    - APP_PRODUCT=$(docker inspect --format='{{ index .Config.Labels "product" }}' ${CI_REGISTRY_IMAGE}/nodered:${IMAGE_TAG})
    - APP_BASE_NAME=$(docker inspect --format='{{ index .Config.Labels "base.name" }}' ${CI_REGISTRY_IMAGE}/nodered:${IMAGE_TAG})
    - APP_VER=$(docker inspect --format='{{ index .Config.Labels "version" }}' ${CI_REGISTRY_IMAGE}/nodered:${IMAGE_TAG})
    - APP_VER_DATE=$(docker inspect --format='{{ index .Config.Labels "release_date" }}' ${CI_REGISTRY_IMAGE}/nodered:${IMAGE_TAG})
    - |
      cat <<EOF > paaas-nodered-release-${IMAGE_TAG}.json
      {
        "vendor": "${APP_VENDOR}",
        "product": "${APP_PRODUCT}",
        "release": "${APP_VER}",
        "release_date": "${APP_VER_DATE}",
        "base_name": "${APP_BASE_NAME}",
        "image_version": "${IMAGE_TAG}",
        "image": "${CI_REGISTRY_IMAGE}/nodered"
      }
      EOF
```

#### Hurl json creation

``` yaml
    - docker tag ${CI_REGISTRY_IMAGE}/hurl:build ${CI_REGISTRY_IMAGE}/hurl:${IMAGE_TAG}
    - docker push ${CI_REGISTRY_IMAGE}/hurl:${IMAGE_TAG}
    - APP_VENDOR=$(docker inspect --format='{{ index .Config.Labels "com.orange.hurl.vendor" }}' ${CI_REGISTRY_IMAGE}/hurl:${IMAGE_TAG})
    - APP_PRODUCT=$(docker inspect --format='{{ index .Config.Labels "com.orange.hurl.title" }}' ${CI_REGISTRY_IMAGE}/hurl:${IMAGE_TAG})
    - APP_VER=$(docker inspect --format='{{ index .Config.Labels "com.orange.hurl.version" }}' ${CI_REGISTRY_IMAGE}/hurl:${IMAGE_TAG})
    - APP_VER_DATE=$(docker inspect --format='{{ index .Config.Labels "com.orange.hurl.created" }}' ${CI_REGISTRY_IMAGE}/hurl:${IMAGE_TAG} | cut -d " " -f1)
    - APP_BASE_NAME=$(docker inspect --format='{{ index .Config.Labels "com.orange.hurl.base.name" }}' ${CI_REGISTRY_IMAGE}/hurl:${IMAGE_TAG})
    - |
      cat <<EOF > paaas-hurl-release-${IMAGE_TAG}.json
      {
        "vendor": "${APP_VENDOR}",
        "product": "${APP_PRODUCT}",
        "release": "${APP_VER}",
        "release_date": "${APP_VER_DATE}",
        "base_name": "${APP_BASE_NAME}",
        "image": "${CI_REGISTRY_IMAGE}/hurl",
        "image_version": "${IMAGE_TAG}"
      }
      EOF
```

#### Deployment of the json into gitlab

Once the json files are generated, still into the pipeline, we update json files present into the project [paaas_image_registry] to add the new version item.

The example below is the json with warpgate image. [warpgate.json][warpgate.json]

```json
{
    "registry.sdlc.webcloud.ec.europa.eu/c4/paaas/warpgate:0.9.4": {
      "vendor": "warpgate_project",
      "product": "warpgate",
      "release": "v0.17.0",
      "release_date": "2025-10-16",
      "base_name": "debian:trixie-slim",
      "image": "registry.sdlc.webcloud.ec.europa.eu/c4/paaas/warpgate",
      "image_version": "0.9.4"
    },
    "registry.sdlc.webcloud.ec.europa.eu/c4/paaas/warpgate:0.9.5": {
      "base_name": "debian:trixie-slim",
      "image": "registry.sdlc.webcloud.ec.europa.eu/c4/paaas/warpgate",
      "image_version": "0.9.5",
      "product": "warpgate",
      "release": "v0.17.0",
      "release_date": "2025-10-16",
      "vendor": "warpgate_project"
    }
  }
```

### Deployment into the netbox

``` mermaid
sequenceDiagram
Automation ->> Gitlab-paaas-registry-image: Fetch properties
Automation ->> Netbox: Create config Context
Automation ->> Netbox: Create Vendors
Automation ->> Netbox: Create Products
```

A new automation has been created:

- to fetch these json from [paaas_image_registry], then create config context with the contents of the jsons
- to create vendor present on the json as manufacturer object
- to create products present on the json as device type object

### Deployment of the PAAAS service

Thanks of the automation of the properties, we can use the config context to deploy the PAAAS service with SACM requirement.

So, when we create a paaas image into netbox, the properties is directly fetch from the config context as the key of the object is `image:version`
And when we deploy the services into the VM, we used properties of the container's image to populate the SACM properties.
 
[sacm-vuln-cmdb]: https://code.europa.eu/digit-c4/compliancy/guidelines/-/blob/main/guidelines/99_Compliancy/Service_asset_and_Configuration_management.md/sacm-vuln-cmdb.md
[sacm-vuln-archi]: https://code.europa.eu/digit-c4/compliancy/guidelines/-/blob/main/guidelines/99_Compliancy/Service_asset_and_Configuration_management.md/sacm-vul-archi.md
[paaas_image_registry]: https://sdlc.webcloud.ec.europa.eu/c4/paaas_image_registry
[warpgate.json]: https://sdlc.webcloud.ec.europa.eu/c4/paaas_image_registry/-/blob/main/paaas/warpgate.json