# TODO for deployment

## Deployment

- [Add in vault a file with all variables needed for the deploiement]
  - if the vault is not available, do something
- deploy paaas_service (warpgate, hurl, nodered) ✅
- [store the keys in vault](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/185)
- [fetch inventory from netbox : all vms](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/129)
- [request add public_key to inventory hosts in authorized_key of snet user (using sys automation)](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/130)
- [create PAAAS role](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/131)
- [create SYS role](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/131)
- [create all target (based on inveentory hosts) and assign to SYS Role](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/129)
- [check host key on each targets (depending authorized_key)](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/186)
- [create SYS users and assign them to SYS Role](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/132)
- [add to users their public key then enable ssh to their profile (new primitive tech)](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/187)
- [create PAAAS users and assign them to PAAAS Role](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/132)
- [Assign ras.ec.local to PAAAS Role (& Admin role ?)](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/132)

## AWX DATA

- Create new role in awx-data to provision PAAAS Service Playbook
- Add our role in provision playbook
- request mappings & certificate --> create an issue for RPS squad
  - [mapping for warpgate.bubble_nms_domain](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/196)
    - certificate for warpgate.bubble_nms_domain
  - [mapping for nodered-paaas.bubble_nms_domain](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/197)
    - certif for nodered-paaas.bubble_nms_domain

## Tasks

- check how works AWX DATA ✅
- maintener awx-data ✅
- [create the paaas vault tree](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/179)
- [request app_role ro for awx-data](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/180)
- [request app_role rw for paaas path](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/181)
- [request app_role ro for paaas_auth_key path for sys](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/182)
- [create json file for SYS team and saved it in vault](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/183)
- [sent path to save sys public key and request to sys the provisionning of their public key](https://sdlc.webcloud.ec.europa.eu/c4/paaas/-/work_items/184)

- Complete the deployment automation to achieve all the deployment steps describe above
