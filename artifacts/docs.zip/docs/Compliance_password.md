# CBD -Password check into repository and production

The purpose of this solution is to build a safe inventory of passwords and secrets found in our repositories, then use this inventory to check if it's used in production.

We want to check if in our production we use default or secret available into the repository, and detect unsafe cases like:

* a default password is still used in production;
* a real secret is committed in Git;
* a password used in NetBox is reused from a repository;
* a required Docker environment variable is missing in NetBox.

We never store real secrets in clear text as we will push them into a repository, so the reports will only contain hashes and metadata.

## Proposed design

1. GitLab Secret Detection runs in the pipeline
2. A second pipeline job creates a normalized inventory file named `repo_scan.json`
3. A third pipeline job checks if actionable findings exist and can fail the pipeline
4. A fourth pipeline job store the normalized inventory in a Gitlab repository

```mermaid
flowchart TD
    subgraph P[Gitlab project pipelines]
        A(Gitlab project repository) -- Repository scan with Gitleaks --> B(gl-secret-detection-report.json)
        B -- create_secret_inventory job --> C(repo_scan.json)
        C -- deploy_secret_inventory job --> D(Inventory Gitlab repository)
        C -- check_secret_inventory job --> E{secret found?}
        E -- yes --> F(pipeline failed)
    end
```

---

5. Deploy this inventory regularly to different NetBox instances

```mermaid
flowchart TD

    D[AWX Hourly Workflow] --> E[Inventory Git repository]
    E --> F[NetBox PAAAS]
    E --> H[NetBox BUBBLE]
```

4. Compare it with NetBox runtime data by a Node-RED instance dedicated to each environment.

```mermaid
flowchart TD
    subgraph PAAAS[PAAAS check]
        AD[API call to PAAAS Node-RED] --> ND[PAAAS Node-RED]
        ND --> FD[NetBox PAAAS]
        FD --> CD[Fetch containers]
        FD --> XD[Fetch config contexts]
        FD --> RD[Fetch repo_scan.json]
        CD --> MD[Compare runtime values with repo_scan.json]
        XD --> MD
        RD --> MD
        MD --> OD[PAAAS compliance result]
        OD --> ZZ[Alert if needed]
    end

    subgraph BUBBLE[BUBBLE check]
        AP[API call to BUBBLE Node-RED] --> NP[BUBBLE Node-RED]
        NP --> HP[NetBox BUBBLE]
        HP --> CP[Fetch containers]
        HP --> XP[Fetch config contexts]
        HP --> RP[Fetch repo_scan.json]
        CP --> MP[Compare runtime values with repo_scan.json]
        XP --> MP
        RP --> MP
        MP --> OP[BUBBLE compliance result]
        OP --> Z[Alert if needed]
    end
```

The secret-detection stage is launch during each pipeline of the main branch, on schedule pipeline, and can be launch using a variable: `RUN_SCAN: true`. The `repo_scan.json` file is not pushed directly to NetBox by the pipeline. It is pushed to the Gitlab Project `PAAAS-Compliance` (central information). Then AWX fetches this repository and deploys the inventory to each NetBox environment with a schedule workflow. This workflow is deploy to AWX thanks to AWX-DATA.

---

## High level workflow

```mermaid
sequenceDiagram
    participant Pipeline as Pipeline
    participant SD as GitLab Secret Detection
    participant Inv as Inventory normalize generation
    participant CheckInv as Inventory check
    participant InvGit as Inventory Git repo
    participant AWX as AWX scheduled workflow
    participant NB as NetBox
    participant Check as Node-RED
    participant Alert as Syslog

    Pipeline->>SD: Run GitLab Secret Detection
    SD->>Pipeline: Create gl-secret-detection-report.json
    Pipeline->>Inv: Normalize report and hash findings
    Inv->>Pipeline: Create repo_scan.json
    Pipeline->>InvGit: Commit repo_scan.json
    Pipeline->>CheckInv: Fail if actionable findings exist

    AWX->>InvGit: Fetch latest inventory
    AWX->>NB: Deploy inventory to Config Context

    Check->>NB: Fetch inventory
    Check->>NB: Fetch NetBox data
    Check->>Check: Compare hashes and required vars
    Check->>Alert: Send alert if needed
```

---

## Main idea

The pipeline creates an inventory of suspicious values found in the repository containing:

* the value/hash found
* the file where it was found
* the related component or service

This report is used to detect if any password is commit into the repository and is stored in GitLab.

The repository scan itself does **not** decide if something is compliant or not, except the part into the pipeline `check_secret_inventory` to detect commited password.
It creates an inventory of passwords found in the code/configuration pushed into a gitlab repository with default password file.

The pipeline implementation is defined here: [CI stage: Secret detection][ci-secret-detection].

Later, a compliance check is done in Node-RED.

Node-RED compares:

* the repository inventory report
* the runtime values coming from NetBox
* the known default password list;
* the required Docker environment variables

If a password used in production (stored in NetBox) is also found in the repository, or is a known default value, an alert is generated.
We also verify if required Docker environment variables are correctly defined in NetBox.

```mermaid
flowchart LR
    A[Repository password inventory] --> C[Compliance check]
    B[NetBox runtime passwords] --> C
    D[Known default password] --> C
    F[Netbox Docker env vars] --> C
    C --> D[Compliance result]
    D --> E[Alert if needed]
```

---

## Normalize inventory details

The generated inventory is stored in the paaas-registry-image repository which will be renamed as `paaas_cbd` or `paaas_compliance`

Example structure:

```text
password-inventory/
├── inventories/
│   ├── local/
│   │   └── repo_scan.json
│   ├── cicd/
│   │   └── repo_scan.json
│   └── repo_scan.json
└── defaults/
   └── default_secrets.txt
```

### Repository inventory file

As we use the `repo_scan.json` file is to do the compliance check, we need to create a "template" for the reports. And to not deploy a secret into gitlab, we will has the secret, so we need the important field `secret_sha256`.

Example:

```json
{
  "schema_version": "1.0",
  "kind": "repo_secret_inventory",
  "app": "my-app",
  "repo": "my-repo",
  "branch": "main",
  "commit": "abc123",
  "scan_date": "2026-05-11T00:00:00Z",
  "findings": [
    {
      "id": "sha256:example-id",
      "component": "ansible_ci_netbox",
      "file": "ansible/roles/deploy_ci_netbox/defaults/main.yml",
      "line": 12,
      "key": "POSTGRES_PASSWORD",
      "secret_sha256": "sha256:example-secret-hash",
      "secret_preview": "known_default:postgres",
      "classification": "KNOWN_DEFAULT",
      "severity": "warning"
    }
  ],
  "summary": {
    "total_findings": 1,
    "known_defaults": 1,
    "possible_real_secrets": 0
  }
}
```

### Normalize inventory classifications

#### KNOWN_DEFAULT

The value is present in `default_secrets.txt`.

Example:

```yaml
POSTGRES_PASSWORD: postgres
```

#### POSSIBLE_REAL_SECRET

The value is not in `default_secrets.txt`.

Example:

```yaml
API_TOKEN: abcd1234-real-token
```

This may be a real secret and should be reviewed.

#### IGNORED_FALSE_POSITIVE

The value is ignored because it is known to be safe or not a real secret.

Example:

```text
password: example
```

This should be managed with allowlist rules.

#### REFERENCE_ONLY

The repository contains a variable reference, not the real value.

Example:

```bash
password="${DB_PASSWORD}"
api_token="$current_token"
```

This is useful information, but it is not a leaked password by itself.


### Security rules

The inventory must never contain raw secrets.

Allowed:

```json
{
  "secret_sha256": "sha256:...",
  "secret_preview": "***"
}
```

Allowed for known defaults:

```json
{
  "secret_preview": "known_default:postgres"
}
```

Not allowed:

```json
{
  "password": "postgres",
  "secret": "real-secret-value",
  "token": "abcd1234"
}
```

The scripts should fail if unsafe fields are found in the generated output.

Examples of unsafe field names:

```text
Secret
secret
Match
match
raw_value
password
```

---

## Workflow to deploy repo_scan.json into NetBox

An Ansible playbook will be added into the PAAAS project.

It will fetch the inventory from the central compliance repository and deploy it to the NetBox instance of the environment.

A new AWX job template and a schedule will be added in `awx-data`.

```mermaid
flowchart TD
    A[AWX] --> B[Scheduled workflow]
    B --> C[Fetch inventory repository]
    C --> D[Deploy to NetBox PAAAS]
    C --> E[Deploy to NetBox BUBBLE]
```

The deployment will create or update a Config Context in each NetBox.

Example Config Context name:

```text
paaas_repo_secret_inventory
```

This Config Context stores the latest `repo_scan.json` for the environment.

---

## Compliance check

A new flow will be added in the Node-RED instance of each environment.

This flow will:

* receive an API call;
* fetch the inventory from NetBox;
* fetch runtime values from NetBox;
* fetch Docker plugin data from NetBox;
* hash runtime values;
* compare runtime hashes with repository hashes;
* compare runtime hashes with known default hashes;
* check if Docker services require environment variables;
* verify if required environment variables are present in NetBox;
* return a compliance result;
* create a Syslog alert if needed.

### Data from NetBox

The compliance check reads data from NetBox.

Possible sources:

```text
- Config Contexts
- Config Templates
- Rendered Configs
- Docker plugin objects
- environment variables
- custom fields, if needed
```

For the Docker plugin, the most important values are usually environment variables.

Example names:

```text
POSTGRES_PASSWORD
REDIS_PASSWORD
NETBOX_SECRET_KEY
API_TOKEN
```

### Compliance check: comparison logic

For each sensitive value found in NetBox:

1. hash the runtime value;
2. check if the hash exists in the repository inventory;
3. check if the hash exists in the default password list;
4. classify the result.

```mermaid
flowchart TD
    A[Runtime value from NetBox] --> B[Hash value]

    B --> C{Found in repository inventory?}
    B --> D{Found in default list?}

    C -->|Yes| E[Runtime equals repository secret]
    C -->|No| F[No repository match]

    D -->|Yes| G[Runtime equals default]
    D -->|No| H[No default match]

    E --> I[Create compliance issue]
    G --> I

    F --> J[Runtime value looks unique]
    H --> J

    K[Docker service definition] --> L[Extract required env vars]
    L --> M[NetBox Docker plugin values]

    M --> N{All required env vars present?}

    N -->|Yes| O[Docker configuration OK]
    N -->|No| P[Create compliance issue]

```

### Compliance check: classifications

#### RUNTIME_SECRET_EQUALS_REPO_SECRET

A value used in NetBox is equal to a secret found in a repository.

Severity: `critical`

#### RUNTIME_SECRET_EQUALS_DEFAULT

A value used in NetBox is equal to a known default value.

Severity: `high`

#### RUNTIME_SECRET_EQUALS_REPO_DEFAULT

A value used in NetBox is equal to a known default, and this same default was also found in a repository.

Severity: `critical`

This is the main case we want to detect.

#### RUNTIME_SECRET_UNIQUE

A value used in NetBox does not match the repository inventory and does not match a known default.

Severity: `info`

This is normally OK.

## Compliance result

The compliance check can produce a compliance result.

Example:

```json
{
  "schema_version": "1.0",
  "kind": "runtime_password_compliance",
  "app": "my-app",
  "environment": "prod",
  "scan_date": "2026-05-11T00:00:00Z",
  "summary": {
    "runtime_secrets_total": 20,
    "runtime_equals_repo": 2,
    "runtime_equals_default": 3,
    "runtime_equals_repo_default": 1,
    "runtime_unique": 15,
    "critical": 1,
    "high": 2,
    "info": 15
  },
  "policy_result": {
    "status": "failed",
    "blocking": true,
    "reason": "1 runtime secret equals a default value found in repository"
  }
}
```

The detailed findings can be stored if needed, but the goal is the alerting.
So, into NODERED, we will check:

```text
policy_result.status
policy_result.blocking
summary.critical
summary.high
```

### Example problem

Repository inventory says that this value was found:

```yaml
POSTGRES_PASSWORD: postgres
```

NetBox runtime config contains:

```yaml
database:
  password: postgres
```

Result:

```text
The runtime password is equal to a known default password.
The same default password was also found in the repository.
This is a critical problem.
```

Classification:

```text
RUNTIME_SECRET_EQUALS_REPO_DEFAULT
```

Recommended action:

```text
- change the production password;
- remove the default value from runtime data;
- keep only secret references in Git;
- use a secret backend if possible.
```

### Example OK case

Repository contains only a reference:

```yaml
POSTGRES_PASSWORD: "${POSTGRES_PASSWORD}"
```

NetBox runtime config contains a real random value:

```yaml
database:
  password: "long-random-production-value"
```

Result:

```text
The repository does not contain the real password.
The runtime value does not match a known default.
The runtime value does not match a repository secret.
This is OK.
```

Classification:

```text
RUNTIME_SECRET_UNIQUE
```

[ci-secret-detection]: ./ci-stage-secret-detection.md
