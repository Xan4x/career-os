# PAAAS Access design

This documentation will be describe all flows about SSH access throught PAAAS service (Warpgate).

## Welcome Workstation

```mermaid
flowchart TD

    subgraph VM["☁️ 🖥️ PAAAS VM"]
        OS(":::3022 LISTEN")
        https(":::3080 LISTEN")
        subgraph Container["📦 Warpgate"]
            App("🚀 Warpgate")
            Monitor("📊 Warpgate-exporter")
      end
    end

    classDef blockStyle fill:#474949,stroke:#6D6E6E,stroke-width:2px,color:#FFFFFF;
    classDef caseBlockStyle fill:#1F2020,stroke:#C7C7C7,color:#d0d0d0,stroke-width:2px;
    classDef caseStyle fill:#1F2020,stroke:#C7C7C7,color:#d0d0d0,stroke-width:2px;

    class VM,Container blockStyle
    class OS,https,App,Monitor caseBlockStyle
    class RPS,W,P,F,L caseStyle

    W(Welcome 💻) -->|TCP_8012| P(🧩 Proxy T2 Cloud)
    P --> | TCP_3022 | F(🧱 FW4)
    F --> | TCP_3022 | L(☁️🔀 Bubble Private LB)
    L --> | TCP_3022 | OS
      
    OS --> | TCP_3022 | App
    Monitor --> | TCP_8888 | App

    W --> | HTTPS | P
    P --> | HTTPS | F
    F --> | HTTPS | L
    L --> | HTTPS | RPS("☁️🔁 RPS")
    RPS --> | TCP_3080 | https
    https --> | TCP_8888 | App

     %% Coloration des flèches
     linkStyle 0 stroke:#1E90FF,stroke-width:2px
    linkStyle 1 stroke:#108989,stroke-width:2px
    linkStyle 2 stroke:#108989,stroke-width:2px
    linkStyle 3 stroke:#108989,stroke-width:2px
    linkStyle 4 stroke:#108989,stroke-width:2px
    linkStyle 5 stroke:#d7a21e,stroke-width:2px
    linkStyle 6 stroke:#8f0a3c,stroke-width:2px
    linkStyle 7 stroke:#8f0a3c,stroke-width:2px
    linkStyle 8 stroke:#8f0a3c,stroke-width:2px
    linkStyle 9 stroke:#8f0a3c,stroke-width:2px
    linkStyle 10 stroke:#8f0a3c,stroke-width:2px
    linkStyle 11 stroke:#8f0a3c,stroke-width:2px

```

### SSH access

1. Enable a TCP connection to the warpgate through a proxy:
<br>On the proxy: connection from welcome laptop IP to Proxy port 8012 with proxyCommand CONNECT to the warpgate server on port 3022.

2. The connection pass throught FW4:
<br>On the fw: a connection from proxy ip to Bubble LB IP on the fw logs.

3. The connection via the direct connectivity arrives at the Bubble LB from the Proxy IP.
4. The Security Group (SG) is opened for this port and forward the session to the PAAaS VM which listen this port: 3022
5. The PAAaS VM forward to the warpgate container on the same port: 3022
<br> the connection is established to the warpgate server.

### HTTPS access

1. HTTPS connection to warpgate pass through the proxy T2 cloud
2. The HTTPS traffic go to FW4
3. Then the Bubble LB forward to the RPS
4. The RPS redirect the traffic to the PAAAS VM wich listen the port 3080
5. The PAAAS VM forward the TCP_3080 to TCP_8888 in the warpgate container

## L4D Workstation

```mermaid
flowchart TD

    subgraph VM["☁️ 🖥️ PAAAS VM"]
        OS(":::3022 LISTEN")
        https(":::3080 LISTEN")
        subgraph Container["📦 Warpgate"]
            App("🚀 Warpgate")
            Monitor("📊 Warpgate-exporter")
      end
    end

    classDef blockStyle fill:#474949,stroke:#6D6E6E,stroke-width:2px,color:#FFFFFF;
    classDef caseBlockStyle fill:#1F2020,stroke:#C7C7C7,color:#d0d0d0,stroke-width:2px;
    classDef caseStyle fill:#1F2020,stroke:#C7C7C7,color:#d0d0d0,stroke-width:2px;

    class VM,Container blockStyle
    class OS,https,App,Monitor caseBlockStyle
    class RPS,W,P,F,L caseStyle

    W(L4D 💻) -->|TCP_8012| P(🧩 Proxy Legacy Cloud)
    P --> | TCP_3022 | F(🧱 FW4)
    F --> | TCP_3022 | L(☁️🔀 Bubble Private LB)
    L --> | TCP_3022 | OS
      
    OS --> | TCP_3022 | App
    Monitor --> | TCP_8888 | App

    W --> | HTTPS | P
    P --> | HTTPS | F
    F --> | HTTPS | L
    L --> | HTTPS | RPS("☁️🔁 RPS")
    RPS --> | TCP_3080 | https
    https --> | TCP_8888 | App

     %% Coloration des flèches
     linkStyle 0 stroke:#1E90FF,stroke-width:2px
    linkStyle 1 stroke:#108989,stroke-width:2px
    linkStyle 2 stroke:#108989,stroke-width:2px
    linkStyle 3 stroke:#108989,stroke-width:2px
    linkStyle 4 stroke:#108989,stroke-width:2px
    linkStyle 5 stroke:#d7a21e,stroke-width:2px
    linkStyle 6 stroke:#8f0a3c,stroke-width:2px
    linkStyle 7 stroke:#8f0a3c,stroke-width:2px
    linkStyle 8 stroke:#8f0a3c,stroke-width:2px
    linkStyle 9 stroke:#8f0a3c,stroke-width:2px
    linkStyle 10 stroke:#8f0a3c,stroke-width:2px
    linkStyle 11 stroke:#8f0a3c,stroke-width:2px

```

### SSH access

1. Enable a TCP connection to the warpgate through a proxy:
<br>On the proxy: connection from L4D laptop IP to Proxy port 8012 with proxyCommand CONNECT to the warpgate server on port 3022.

2. The connection pass throught FW4:
<br>On the fw: a connection from proxy ip to Bubble LB IP on the fw logs.

3. The connection via the direct connectivity arrives at the Bubble LB from the Proxy IP.
4. The Security Group (SG) is opened for this port and forward the session to the PAAaS VM which listen this port: 3022
5. The PAAaS VM forward to the warpgate container on the same port: 3022
<br> the connection is established to the warpgate server.

### HTTPS access

1. HTTPS connection to warpgate pass through the proxy cloud legacy
2. The HTTPS traffic go to FW4
3. Then the Bubble LB forward to the RPS
4. The RPS redirect the traffic to the PAAAS VM wich listen the port 3080
5. The PAAAS VM forward the TCP_3080 to TCP_8888 in the warpgate container
