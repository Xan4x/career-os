# CBD - CI - Secret detection

## secret-detection files

The secret detection stage based on folder `compliance/secret-detection`, so this folder and its contents are necessary in the project:

```text
project_repository/
└── compliance/
    └── secret-detection/
       ├── components.map
       ├── default_secrets.txt
       ├── extended-gitleaks-config.toml
       ├── normalize_secret_detection_report.sh
       └── secret-detection-stage-template.yml
```

---

### Component map

The `components.map` file maps repository paths to logical components.

Example:

```text
ansible_ci_netbox=ansible/roles/deploy_ci_netbox
cicd_awx=cicd/awx
netbox_paaas=cicd/netbox-paaas
documentation=doc
documentation=docs
teleport=teleport
```

If a finding has `component: unknown`, it means the file path does not match any line in `components.map`.

Example:

```text
doc/Boundary-controller.md
```

This needs a mapping like:

```text
documentation=doc
```

### Known default secrets

The file `default_secrets.txt` contains the list of known default passwords or unsafe default values.

One value is defined per line.

Example:

```text
admin
password
passwd
test
postgres
netbox
netbox123
redis
```

If a secret found in the repository matches one of these values, it is classified as `KNOWN_DEFAULT`.

These values are not treated as real leaked secrets in the repository inventory, but they are important for the runtime check.

If NetBox uses one of these values in production, it is a compliance issue.

### Gitleaks configuration

The file `extended-gitleaks-config.toml` contains the custom Gitleaks rules used by the GitLab Secret Detection analyzer.

The GitLab analyzer already provides default rules. This file adds project-specific rules, for example to detect passwords in Docker Compose, Ansible files, or project configuration files.

Example rule:

```toml
[[rules]]
id = "docker-compose-passwords"
description = "Docker compose passwords"
regex = '''(?i)(password|passwd|secret|token)[[:space:]]*[:=][[:space:]]*["']?[^[:space:]"']+'''
tags = ["docker", "password"]
```

This can detect values like:

```yaml
environment:
  POSTGRES_PASSWORD: postgres
  REDIS_PASSWORD: redis
```

### normalize_secret_detection_report.sh

This script reads the GitLab Secret Detection report: `gl-secret-detection-report.json` and creates the normalized business inventory: `reports/repo_scan.json`

The script is responsible for:

* reading the GitLab report;
* extracting useful metadata;
* hashing secret values;
* classifying findings;
* mapping files to components;
* filtering inventory-only exclusions;
* removing unsafe raw values from the final inventory.

#### Details

The input report is the GitLab security report.

Example simplified structure:

```json
{
  "version": "15.2.4",
  "vulnerabilities": [
    {
      "category": "secret_detection",
      "name": "Password in URL",
      "raw_source_code_extract": "postgresql://User:Passs@DBServer.local",
      "location": {
        "file": "doc/Boundary-controller.md",
        "start_line": 153,
        "commit": {
          "sha": "74597e33b0bd2f309425321c198f7559c9f674a0"
        }
      },
      "identifiers": [
        {
          "type": "gitleaks_rule_id",
          "value": "Password in URL"
        }
      ]
    }
  ]
}
```

The normalizer reads:

```text
vulnerabilities[].raw_source_code_extract
vulnerabilities[].location.file
vulnerabilities[].location.start_line
vulnerabilities[].location.commit.sha
vulnerabilities[].identifiers[].value
```

For `Password in URL`, the script must extract only the password part before hashing.

Example:

```text
postgresql://User:Passs@DBServer.local
```

The value used for hashing is:

```text
Passs
```

The report must not store `Passs` or the full URL.

---

### secret-detection-stage-template.yml

This file contains the GitLab CI templates for the secret detection pipeline.

It defines the common jobs used by projects:

```text
secret_detection
create_secret_inventory
check_secret_inventory
deploy_secret_inventory #WIP
```

Projects can include this template in their .gitlab-ci.yml and extend the jobs instead of redefining all the logic.

Example:

``` yaml
include:
  - local: compliance/secret-detection/secret-detection-stage-template.yml
```

Then the project can define:

``` yaml
secret_detection:
  extends:
    - .docker
    - .secret-detection-template

create_secret_inventory:
  extends:
    - .docker
    - .create-secret-inventory-template

check_secret_inventory:
  extends:
    - .docker
    - .check-secret-inventory-template
```

## Pipeline Implementation

The pipeline has tree main jobs for this feature, a fourth job will be added to publish the repository to the inventory compliance repository:

* secret_detection
* create_secret_inventory
* check_secret_inventory
* deploy_secret_inventory

### Included jobs in `.gitlab-ci.yml`

Application repositories can include a shared CI template and only define small jobs like this:

```yaml
secret_detection:
  extends:
    - .docker
    - .secret-detection-template
  variables:
    SECRET_DETECTION_EXCLUDED_PATHS: "examples,node_modules,test,tests,build,teleport/data,cicd/awx/awx-data"

create_secret_inventory:
  extends:
    - .docker
    - .create-secret-inventory-template
  needs:
    - job: secret_detection
      artifacts: true

# deploy_secret_inventory:
#   extends:
#     - .docker
#     - .deploy-secret-inventory-template # TODO

check_secret_inventory:
  extends:
    - .docker
    - .check-secret-inventory-template
```

The templates are defined in a file included at the beginning of the GitLab CI file:

```yaml
include:
  - local: 'compliance/secret-detection/secret-detection-stage-template.yml'
```

And the variable to launch the jobs in standard pipeline is define:

```yaml
variables:
  RUN_SCAN: false
```

---

## Job details

### Job: secret_detection

This job uses the GitLab Secret Detection analyzer image.

The analyzer runs Gitleaks internally and creates the GitLab security report:

``` text
gl-secret-detection-report.json
```

Template used:

```yaml
.secret-detection-template:
  stage: secret-detection
  rules:
    # Full historical scan only during scheduled pipelines
    - if: '$CI_PIPELINE_SOURCE == "schedule"'
      variables:
        SECRET_DETECTION_HISTORIC_SCAN: "true"
    # Mandatory scan on main branch
    - if: '$CI_COMMIT_BRANCH == "main"'
    # Mandatory scan on release tags
    - if: '$CI_COMMIT_TAG'
    # Scan on-demande for test
    - if: '$RUN_SCAN == true'
      variables:
        SECRET_DETECTION_HISTORIC_SCAN: "true"
    # - when: always
  image:
    name: registry.gitlab.com/security-products/secrets:7
    entrypoint: [""]
  variables:
    SECURE_ENABLE_LOCAL_CONFIGURATION: "true"
    SECRET_DETECTION_HISTORIC_SCAN: "false"
    # SECRET_DETECTION_EXCLUDED_PATHS: "examples,node_modules,test,tests,build,teleport/data,cicd/awx/awx-data"
  script:
    - echo "GITLAB_CI=$GITLAB_CI"
    - rm -f gl-secret-detection-report.json config.tmp
    - cp /gitleaks.toml gitleaks.toml.bak
    - |
     awk '
     FNR==NR {
       if (/^\[\[rules\]\]/) r=1
       else if (/^\[\[/ && r) r=0
       if (r) rules = rules $0 ORS
       next
     }

     /^\[\[allowlists\]\]/ && !done {
       printf "%s\n", rules
       done=1
     }

     { print }

     END {
       if (!done) {
       print "Erreur: bloc [[allowlists]] introuvable dans config.toml" > "/dev/stderr"
       exit 1
       }
     }
     ' compliance/secret-detection/extended-gitleaks-config.toml /gitleaks.toml > config.tmp
    - mv config.tmp /gitleaks.toml
    - /analyzer run
  artifacts:
    when: always
    paths:
      - gl-secret-detection-report.json
    reports:
      secret_detection: gl-secret-detection-report.json
    expire_in: "3 hours"
```

---

### Job: create_secret_inventory

This job reads `gl-secret-detection-report.json` and creates:

```text
reports/repo_scan.json
```

It uses the script: `compliance/secret-detection/normalize_secret_detection_report.sh`

This script accepts only the GitLab Secret Detection report format.

Extract of the template used into the job:

```yaml
.create-secret-inventory-template:
  stage: secret-detection
  rules:
    # Full historical scan only during scheduled pipelines
    - if: '$CI_PIPELINE_SOURCE == "schedule"'
    # Mandatory scan on main branch
    - if: '$CI_COMMIT_BRANCH == "main"'
    # Mandatory scan on release tags
    - if: '$CI_COMMIT_TAG'
    # Scan on-demande for test
    - if: '$RUN_SCAN == true'
    # - when: always
  needs:
    - job: secret_detection
      artifacts: true
  before_script:
    - apk add --no-cache bash jq coreutils
    - if [ "$GITLAB_CI" = "false" ]; then export INVENTORY_EXCLUDED_PATHS="cicd/vault/vault_secrets.json,.gitlab-ci-local-variables.yml,ansible/paaas_techvars.json,cicd/vault/.vault_credentials.env"; fi
  script:
    - mkdir -p reports
    - bash compliance/secret-detection/normalize_secret_detection_report.sh gl-secret-detection-report.json reports/repo_scan.json
    - |
      jq '
      {
        schema_version: .schema_version,
        kind: "repo_secret_inventory_non_default_findings",
        app: .app,
        repo: .repo,
        branch: .branch,
        commit: .commit,
        scan_date: .scan_date,
        summary: {
          total_non_default_findings: (
            [
              .findings[]
              | select(
                  .classification != "KNOWN_DEFAULT"
                  and .classification != "REFERENCE_ONLY"
                  and .classification != "IGNORED_FALSE_POSITIVE"
                )
            ] | length
          )
        },
        findings: [
          .findings[]
          | select(
              .classification != "KNOWN_DEFAULT"
              and .classification != "REFERENCE_ONLY"
              and .classification != "IGNORED_FALSE_POSITIVE"
            )
          | {
              component,
              file,
              line,
              key,
              rule_id,
              classification,
              severity
            }
        ]
      }
      ' reports/repo_scan.json > reports/repo_scan_non_default_findings.json
  artifacts:
    when: always
    paths:
      - reports/repo_scan.json
      - reports/repo_scan_non_default_findings.json
    expire_in: "3 hours"
```

#### Local-ci needs: inventory exclusion

GitLab Secret Detection may still report files we do not want in the inventory, for this reason, the normalizer supports:

```text
INVENTORY_EXCLUDED_PATHS
```

Example:

```text
INVENTORY_EXCLUDED_PATHS="cicd/vault/vault_secrets.json,teleport/data,.gitlab-ci-local-variables.yml"
```

This does not change the GitLab Secret Detection report.

It only prevents selected findings from being copied into `repo_scan.json`.

Excluded findings can still be tracked safely in `excluded_findings[]`, without raw secret values.

---

### Job: deploy_secret_inventory

This job push `repo_scan.json` to the central compliance repository.

Template WIP 🚧:

```yaml
.deploy-secret-inventory-template:
  stage: secret-detection
  needs:
    - job: create_secret_inventory
      artifacts: true
  script:
    - echo "todo"
```

---

### Job: check_secret_inventory

This job checks if the generated inventory contains actionable findings.

It fails the pipeline only when a finding is not:

* `KNOWN_DEFAULT`;
* `REFERENCE_ONLY`;
* `IGNORED_FALSE_POSITIVE`.

Template extract:

```yaml
.check-secret-inventory-template:
  stage: secret-detection
  rules:
    # Full historical scan only during scheduled pipelines
    - if: '$CI_PIPELINE_SOURCE == "schedule"'
    # Mandatory scan on main branch
    - if: '$CI_COMMIT_BRANCH == "main"'
    # Mandatory scan on release tags
    - if: '$CI_COMMIT_TAG'
    # Scan on-demande for test
    - if: '$RUN_SCAN == true'
    # - when: always
  needs:
    # job: deploy_secret_inventory
    - job: create_secret_inventory
      artifacts: true
  before_script:
    - apk add --no-cache bash jq coreutils
  script:
    - |
      ACTIONABLE_FINDINGS="$(jq -r '.summary.total_non_default_findings' reports/repo_scan_non_default_findings.json)"
      if [ "$ACTIONABLE_FINDINGS" -gt 0 ]; then
        echo "ERROR: $ACTIONABLE_FINDINGS secret finding(s) found"
        jq '.findings' reports/repo_scan_non_default_findings.json
        exit 1
      fi
  artifacts:
    when: always
    paths:
      - reports/repo_scan.json
      - reports/repo_scan_non_default_findings.json
    expire_in: "3 hours"
```

This job does not print secrets or hashes in logs.

It only prints impacted files, line numbers, classifications and rules.
