# Client compatibility

This document is to describe the client compatibility

|                                       | Putty<br>(Windows) | MobaXterm <br>(Windows) | Native client<br>(Windows) | Bastion<br>(Debian - Vjump) | L4D workstation |
| ------------------------------------- | ------------------ | ----------------------- | -------------------------- | --------------------------- | --------------- |
| SSH with ProxyCommand                 |         ✔️        |            ❌           |              ❌            |              ✔️            |        ✔️       |
| SSH with ProxyCommand & X11 forwading |         ❌        |            ❌           |              ❌            |              ✔️            |        not tested       |

## Notes

- Some test was done with MobaXterm, Native client and for the moment no solution was found to use these clients.
- Putty  issue with X11 forwarding, issue opened to warpgate project : https://github.com/warp-tech/warpgate/issues/1375
