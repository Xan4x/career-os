# PAAAS CI/CD

As explained in the [High/Level CI/CD overview][cicd_overview], PAAAS is fully build & tested in the PAAAS CI/CD. All automatation done for this service is tested on the pipeline.

## Pipeline: sequence diagram

```mermaid
sequenceDiagram
Gitlab ->> paaas-runner: Proceed to secret-detection
Gitlab ->> paaas-runner: Proceed to code-review
Gitlab ->> paaas-runner: Build documentations
Gitlab ->> paaas-runner: Pre-cleanning
Gitlab ->> paaas-runner: Build & Test warpgate:build version
Gitlab ->> paaas-runner: Build & Test nodered:build version
Gitlab ->> paaas-runner: Build & Test hurl:build version
paaas-runner ->> Gitlab: Deploy build version of warpgate, nodered, hurl
Gitlab ->> paaas-runner: Deploy into netbox the paaas service: warpgate:build, hurl:build, nodered:build
Gitlab ->> paaas-runner: Test the service on the build version
Gitlab ->> paaas-runner: Test creation of the targets in paaas service on the build version
Gitlab ->> paaas-runner: cleanning
note over Gitlab, galaxy-runner: if we merge in MAIN branch: we create the latest version
Gitlab ->> paaas-runner: Build & Test warpgate:latest version
Gitlab ->> paaas-runner: Build & Test nodered:latest version
Gitlab ->> paaas-runner: Build & Test hurl:latest version
paaas-runner ->> Gitlab: Deploy latest version of warpgate, nodered, hurl
Gitlab ->> paaas-runner: Deploy into netbox the paaas service: warpgate:latest, hurl:latest, nodered:latest
Gitlab ->> paaas-runner: Test the service on the latest version
Gitlab ->> paaas-runner: Test creation of the targets in paaas service on the latest version
note over Gitlab, galaxy-runner: Test in acceptance bubble
Gitlab ->> galaxy-runner: Deploy into bubble_paaas's netbox the paaas service: warpgate:latest, hurl:latest, nodered:latest
Gitlab ->> galaxy-runner: Test the service on the latest version into bubble_paaas
Gitlab ->> galaxy-runner: Test creation of the targets into bubble_paaas
note over Gitlab, galaxy-runner: if we create a new release: we create the TAG version
paaas-runner ->> Gitlab: if Tag: Deploy Tag version of warpgate, nodered, hurl
```

### Build stages into paaas runner

```mermaid
sequenceDiagram
    note over runner, warpgate: Create & test Exporter
    runner ->> warpgate: Build exporter
    runner ->> warpgate: Run hurl-exporter
    hurl ->> warpgate: Test exporter
    note over runner, nodered: Create and test Build version
    runner ->> warpgate: Build and run image warpagte:build
    runner ->> hurl: Build and run image hurl:build
    runner ->> nodered: Build and run image nodered:build
    hurl ->> warpgate: Test warpgate:build
    hurl ->> nodered: Test nodered:
    hurl ->> hurl: Test hurl:build
    note over runner, Gitlab: Deploy Build version & clean the runner
    runner ->> Gitlab: Deploy warpgate, hurl & nodered in build version
    runner ->> warpgate: clean warpgate:build
    runner ->> nodered: clean nodered:build
    runner ->> hurl: Clean hurl-build
    note over runner, netbox: Deploy Service as a bubble in Build version
    runner ->> netbox: Playbook to create registry, pull images
    runner ->> vault: fetch app-role & account netbox
    netbox ->> warpgate: Playbook deploy warpagte:build
    netbox ->> hurl: Playbook to deploy hurl:build
    netbox ->> nodered: Playbook to deploy nodered:build
    note over runner, netbox: Test the service
    runner ->> netbox: playbook to launch tests
    netbox ->> hurl: Start hurls
    hurl ->> warpgate: Test Warpgate
    hurl ->> nodered: Test primitives
    runner ->> netbox: fetch app-role & account nodered & netbox
    runner ->> nodered: playbook to creates targets
    nodered ->> warpgate: all targets are creating
    note over runner, netbox: clean the runner
    runner ->> warpgate: clean warpgate:build
    runner ->> nodered: clean nodered:build
    runner ->> hurl: Clean hurl:build
```

### Latest stages into paaas runner

```mermaid
sequenceDiagram
    note over runner, nodered: Create and test latest version
    runner ->> warpgate: tag build image to warpagte:latest
    runner ->> hurl: tag build image to hurl-paaas:latest
    runner ->> nodered: tag build image to nodered:latest
    runner ->> hurl: Run hurl-latest
    hurl ->> warpgate: Test warpgate:latest
    hurl ->> nodered: Test nodered:latest
    hurl ->> hurl: Test hurl-paaas:latest
    note over runner, Gitlab: Deploy Latest version & clean the runner
    runner ->> Gitlab: Deploy warpgate, hurl & nodered in latest version
    runner ->> warpgate: clean warpgate:latest
    runner ->> nodered: clean nodered:latest
    runner ->> hurl: Clean hurl-latest
    note over runner, netbox: Deploy Service as a bubble in latest version
    runner ->> netbox: Playbook to create registry, pull images
    runner ->> vault: fetch app-role & account netbox
    netbox ->> warpgate: Playbook deploy warpagte:latest
    netbox ->> hurl: Playbook to deploy hurl:latest
    netbox ->> nodered: Playbook to deploy nodered:latest
    note over runner, netbox: Test the service
    runner ->> netbox: playbook to launch tests
    netbox ->> hurl: Start hurls
    hurl ->> warpgate: Test Warpgate
    hurl ->> nodered: Test primitives
    runner ->> vault: fetch app-role & account nodered & netbox
    runner ->> nodered: playbook to creates targets
    nodered ->> warpgate: all targets are creating
    note over runner, netbox: clean the runner
    runner ->> warpgate: clean warpgate:latest
    runner ->> nodered: clean nodered:latest
    runner ->> hurl: Clean hurl:latest
```

## Pipeline details

In each job, all task was done into a docker to avoid issue with dependance into the runner.

To complete the test, we need to add a Netbox into the pipeline. Due to some issue with netbox agent and the shared runner, a dedicated runner for PAAAS CICD is available in PAAAS acceptance bubble.
</br>It would also let us validate our components across different versions, as well as ensure the continuity of our service, for example, by testing our service with a new version of Netbox.

The pipeline is full http, we don't use any ssh connection.

![cicd](./images/PAAAS-cicd.jpg)

### Vars

We use YAML anchor to define some variables use in different job into the pipline.

- default-vars
- test-exporter-vars
- default-hurl-vars
- default-app-vars
- default-nodered-vars
- default-test-vars

And some global variables is defined:

``` yaml
variables:
  netbox_version: "v3.7.8-r1"
  tag_version: "0.9.5"
  trivy_version: "0.70.0"
  tag_prod: "0.9.6"
  NODERED_VERSION: "4.1.9-minimal"
  RUN_SCAN: false
```

### Templates

We include into the `.gitlab-ci.yml` another yml file where is defined all templates used in jobs: `templates/gitlab-ci-templates.yml`

Almost all script are defined in this another file and only the variable used change the result of the job.

We include also the template file `compliance/secret-detection-stage-template.yml` which contains the template for job of the `secret-dection` stage.

### Stages

The based docker images used on this project:

- `.go: golang:1.24`: to avoid the installation of GO on the runner in order to check the code of the warpgate-exporter.
- `.docker: docker:latest`: as already explained, to avoid any dependancies issue.

Basically, if it's not specified on the stage details, the job run `.docker` by default.

#### Secret detection

Into the [Password check][password_check] process we use the pipeline to create the inventory of secret available into the repository. The secret detection jobs as described into the [documentation][ci_secret_detection]

#### Code Review

On this stage, we review all go & ansible code done on the PAAAS project:

- **Ansible_lint**: Through the `.docker`, we start an `alpine/ansible image` and add ansible-lint to proceed to the check of all ansible files in ansible folder.
- **go_lint**: Through `.go`, we launch the `golangci/golangci-lint:v2.1.6-alpine` to proceed to check the GO code present in warpgate-exporter folder.
- **go_duplication**: Through `.go`, we launch the image `registry.gitlab.com/gitlab-ci-utils/gitlab-pmd-cpd:latest` and proceed to a check of duplacation code.

#### Pre-Clean

On this stage we clean all composent which should clean at the end of the pipeline but still present in case of pipeline failed.

#### Build exporter

On this stage, we build the binary of the warpgate-exporter which will added on the warpgate image.

#### Test exporter

To test the exporter, we create a container which contains the binary, a hurl container and proceed to exec some hurl tests defined on the `hurl/tests/` folder to validate the exporter.
Once done, we clean the composents.

#### Build PAAAS

On this stage, we create  the latest version of the primitive openapi.json which will be publish into the [OpenAPI publish on PAAAS Pages][openapi] & on the nodered image:
Using the CMDB official image of smithy `registry.sdlc.webcloud.ec.europa.eu/c4/docs-toolbox/smithy:latest`, we validate and build the smithy defined on the smithy folder to create the openapi.json. Same process is used to create also the [Compliance OpenAPI published on PAAAS Pages][compliance_openapi]

Then we build all PAAAS service components:

- warpgate: the paaas image
- nodered: used to publish primitives
- hurl: used to test the PAAAS service

So, we build these 3 images and tag its as `build-version`
</br>The nodered contains all primitives defined on the [PAAAS pages][openapi]
</br>The hurl image contains all tests defined to tests the service and to tests each primitives. The entrypoint is the script which launch all tests.

#### Test Build PAAAS

We start each paaas images and one another hurl container to proceed to test the images.
</br>If all tests passed, we publish in the gitlab registry the build version of the components of the PAAAS service.

#### Test build PAAAS service

On this stage, we proceed to deploy the PAAAS service as it should be done on bubbles to tests the automation. We deploy also a vault container - to emulate the production vault - which contains all secrets needed by the automation.

- Deploy the sacm image propeties as done on the bubble.
- Create the secrets of each components as done into the bubble.
- Deploy with the playbook `deploy-paaas-service` the warpgate, nodered and hurl container through the netbox present on the runner using the *build* image from the registry.
- Test the service, as done on the bubble, using the playbook `run-hurl-paaas` which starts the hurl container and check the result of all test publish on the hurl image.
- Test the creation of the targets, as done on the bubble, using the playbook `deploy-paaas-targets`
- Test the create of the users, as done on the bubble, using the playbook `deploy-paaas-users`
- Test the create of the roles, as done on the bubble, using the playbook `deploy-paaas-roles`
- Test the fetch and store of the public key

#### Deploy PAAAS image

If we are on the **MAIN BRANCH** and all test done with build version was successfull we proceed to deploy a latest version on the gitlab registry.
Based on the label, a json is publish into the project [paaas_image_registry][paaas_image_registry] with properties of the image.

#### Generate Badges

In this stage, based on the Dockerfile, we create a json with version of the products into the paaas image, then publich a badge image to publish into the project.
We also generate the cmpdb-netbox and the docker-api badges.

#### Build Doc

On this stage, we create the latest version of the [PAAAS Pages][homepage]: Using CMDB image `registry.sdlc.webcloud.ec.europa.eu/c4/docs-toolbox/mkdocs:latest`, we build the web pages publish on the [PAAAS pages][homepage] (based on the `mkdocs.yml`)

#### Test PAAAS image

We proceed to the same tests done on test-build-paaas but with the latest image: we start each paaas images and one another hurl container to proceed to test the images.

#### Test PAAAS image service

As done with build image, we proceed to deploy the PAAAS service as it should be done on bubbles to tests the automation. We deploy also a vault container - to emulate the production vault - which contains all secrets needed by the automation.

- Deploy the sacm image propeties as done on the bubble.
- Create the secrets of each components as done into the bubble.
- Deploy with the playbook `deploy-paaas-service` the warpgate, nodered and hurl container through the netbox present on the runner using the *latest* image from the registry.
- Test the service, as done on the bubble, using the playbook `run-hurl-paaas` which starts the hurl container and check the result of all test publish on the hurl image.
- Test the creation of the targets, as done on the bubble, using the playbook `deploy-paaas-targets`
- Test the create of the users, as done on the bubble, using the playbook `deploy-paaas-users`
- Test the create of the roles, as done on the bubble, using the playbook `deploy-paaas-roles`
- Test the fetch and store of the public key

#### Scan images

Into the pipeline, we scan the image using the trivy image, to create a report about vulnerabilities in our images.
We generate a report for latest and production tags of each paaas components.

#### Deploy PAAAS aws

To validate, we deploy the new latest version of the PAAAS service in bubble_paaas which is the PAAAS acceptance environment through the galaxy runner. This stage can't be launch with local-ci.

- Deploy if needed the netbox secrets with `create-netbox-paaas-secrets.yml`
- Deploy the image properties with the playbook `deploy-paaas-images-properties.yml`
- Deploy if needed the warpgate secrets with the playbook `create-paaas-admin-password.yml`
- Deploy if needed the nodered secrets with the playbook `create-paaas-nodered-secrets.yml`
- Deploy/Update with the playbook `deploy-paaas-service` the warpgate, nodered and hurl container through the bubble's netbox using the *latest* image from the registry.

#### Test PAAAS aws

And we complete the validation by test done directly on the acceptance environment through the galasy runner. This stage can't be launch with local-ci.

- Test if new image is available of the update of one components.
- Test the service using the playbook `run-hurl-paaas` which starts the hurl container and check the result of all test publish on the hurl image.
- Test the creation of the warpgate token using the playbook `deploy-paaas-token`
- Save the paaas bubble public key into the vault with `save-paaas-ssh-keys.yml`
- Test the creation of the targets using the playbook `deploy-paaas-targets`
- Test the creation of the users using the playbook `deploy-paaas-users`
- Test the creation of the roles using the playbook `deploy-paaas-roles`

#### Deploy PAAAS release

On this stage, if a new release is requested and if all tests are successfull, we deploy a new version based on the latest version which has been tested on this pipeline.
We also generate a trivy for each components on this new tags.

#### Deploy

We deploy the latest version of the [PAAAS Pages][homepage]

#### Clean

We proceed to the cleaning of all components, trace still present in both runner (and localy also if launch by local-ci).

[cicd_overview]: ./PAAAS_Project_Overview.md#highlevel-cicdoverview
[homepage]: ./index.md
[openapi]: ./openapi.html
[compliance_openapi]: ./openapiCompliance.html
[paaas_image_registry]: https://sdlc.webcloud.ec.europa.eu/c4/paaas_image_registry
[password_check]: ./Compliance_password.md
[ci_secret_detection]: ./ci-stage-secret-detection.md
